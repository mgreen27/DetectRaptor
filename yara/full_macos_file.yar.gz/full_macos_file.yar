private rule BINARYALERT_Macho_PRIVATE : FILE {
    meta:
		description = "Mach-O binaries"
		author = "Airbnb"
		id = "04e14811-38be-54eb-8ec0-649d5469078a"
		date = "2017-08-11"
		modified = "2017-08-11"
		reference = "https://github.com/airbnb/binaryalert/"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/MachO.yara#L1-L7"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "2e992eb7d4ea47c9f61f3a7d8b0b6e37d0423fb08a626eaf2ddea51bfd928dfc"
		score = 75
		quality = 80
		tags = "FILE"

	condition:
		uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xcafebabe or uint32( 0 ) == 0xbebafeca
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Roxlu_Ofxkeylogger {
    meta:
		description = "ofxKeylogger keylogger."
		author = "@mimeframe"
		id = "c0e00b76-9623-5709-b64b-0afe006eba60"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/roxlu/ofxKeylogger"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_roxlu_ofxkeylogger.yara#L1-L13"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "6e2579a10327cc8f1799848b3bcbcd95733a31098faeb849df6ebf99f1ffe808"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "keylogger_init" wide ascii
		$a2 = "install_keylogger_hook function not found in dll." wide ascii
		$a3 = "keylogger_set_callback" wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Logkext {
    meta:
		description = "LogKext is an open source keylogger for Mac OS X, a product of FSB software."
		author = "@mimeframe"
		id = "2e4ad9d0-5780-5a28-a76d-baac401b0648"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/SlEePlEs5/logKext"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_logkext.yara#L1-L25"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "f0e3a7ea8ec4568c319e44f00d71fb368948b6fe08bdf86de4b33f0d2bafbb44"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "logKextPassKey" wide ascii
		$a2 = "Couldn't get system keychain:" wide ascii
		$a3 = "Error finding secret in keychain" wide ascii
		$a4 = "com_fsb_iokit_logKext" wide ascii
		$b1 = "logKext Password:" wide ascii
		$b2 = "Logging controls whether the daemon is logging keystrokes (default is on)." wide ascii
		$c1 = "logKextPassKey" wide ascii
		$c2 = "Error: couldn't create secAccess" wide ascii
		$d1 = "IOHIKeyboard" wide ascii
		$d2 = "Clear keyboards called with kextkeys" wide ascii
		$d3 = "Added notification for keyboard" wide ascii

	condition:
		3 of ( $a* ) or all of ( $b* ) or all of ( $c* ) or all of ( $d* )
}
rule BINARYALERT_Hacktool_Macos_N0Fate_Chainbreaker {
    meta:
		description = "chainbreaker can extract user credential in a Keychain file with Master Key or user password in forensically sound manner."
		author = "@mimeframe"
		id = "565d31c6-8d80-534d-8acc-c01d7af4f8b3"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/n0fate/chainbreaker"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_n0fate_chainbreaker.yara#L1-L13"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "7aedf952756ed2375ff171329179f14a8cdc37ada69e1f003def1f1de5bc1691"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "[!] Private Key Table is not available" wide ascii
		$a2 = "[!] Public Key Table is not available" wide ascii
		$a3 = "[-] Decrypted Private Key" wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Manwhoami_Osxchromedecrypt {
    meta:
		description = "Decrypt Google Chrome / Chromium passwords and credit cards on macOS / OS X."
		author = "@mimeframe"
		id = "874cc999-d9c2-5017-83ec-e4be8a659476"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/manwhoami/OSXChromeDecrypt"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_manwhoami_osxchromedecrypt.yara#L1-L16"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "0974c6a5e7875e20380df0f58bf22a589b9a5c718e635ec77b42060abcf99473"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "Credit Cards for Chrome Profile" wide ascii
		$a2 = "Passwords for Chrome Profile" wide ascii
		$a3 = "Unknown Card Issuer" wide ascii
		$a4 = "ERROR getting Chrome Safe Storage Key" wide ascii
		$b1 = "select name_on_card, card_number_encrypted, expiration_month, expiration_year from credit_cards" wide ascii
		$b2 = "select username_value, password_value, origin_url, submit_element from logins" wide ascii

	condition:
		3 of ( $a* ) or all of ( $b* )
}
rule BINARYALERT_Hacktool_Macos_Manwhoami_Mmetokendecrypt {
    meta:
		description = "This program decrypts / extracts all authorization tokens on macOS / OS X / OSX."
		author = "@mimeframe"
		id = "2dc01ff3-4c4a-548d-b2f0-b36897ad6a5c"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/manwhoami/MMeTokenDecrypt"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_manwhoami_mmetokendecrypt.yara#L1-L15"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "ccfedfbff0c6eefe41e80fe488d4cae928a33e7b86019c6ec54d1c9005b35147"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "security find-generic-password -ws 'iCloud'" wide ascii
		$a2 = "ERROR getting iCloud Decryption Key" wide ascii
		$a3 = "Could not find MMeTokenFile. You can specify the file manually." wide ascii
		$a4 = "Decrypting token plist ->" wide ascii
		$a5 = "Successfully decrypted token plist!" wide ascii

	condition:
		3 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Ptoomey3_Keychain_Dumper {
    meta:
		description = "Keychain dumping utility."
		author = "@mimeframe"
		id = "c45abbbe-f5fe-5a87-acd4-dcdb99ceec28"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/ptoomey3/Keychain-Dumper"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_ptoomey3_keychain_dumper.yara#L1-L15"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "f2ef979e4682ce617b37f7503ec2ca520e657b4f6d15a75afad59b62191a1a43"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "keychain_dumper" wide ascii
		$a2 = "/var/Keychains/keychain-2.db" wide ascii
		$a3 = "<key>keychain-access-groups</key>" wide ascii
		$a4 = "SELECT DISTINCT agrp FROM genp UNION SELECT DISTINCT agrp FROM inet" wide ascii
		$a5 = "dumpEntitlements" wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Dannvix {
    meta:
		description = "A simple keylogger for macOS."
		author = "@mimeframe"
		id = "598d6dbc-540d-5f96-8bd1-c15e6194012e"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/dannvix/keylogger-osx"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_dannvix.yara#L1-L13"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "95d0540b1308caf3e7287c70a759954650220192800c0154d225bcb01ed55766"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "/var/log/keystroke.log" wide ascii
		$a2 = "<forward-delete>" wide ascii
		$a3 = "<unknown>" wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Exploit_Cve_5889 {
    meta:
		description = "No description has been set in the source file - BinaryAlert"
		author = "@mimeframe"
		id = "ea70d31c-1b70-5927-ba8d-e13d2114e74e"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://www.exploit-db.com/exploits/38371/"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_exploit_cve_2015_5889.yara#L1-L16"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "b455759ea369cdcf2f05a2735a38000179ebe644667016cd635dfad9beda4459"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "/etc/sudoers" fullword wide ascii
		$a2 = "/etc/crontab" fullword wide ascii
		$a3 = "* * * * * root echo" wide ascii
		$a4 = "ALL ALL=(ALL) NOPASSWD: ALL" wide ascii
		$a5 = "/usr/bin/rsh" fullword wide ascii
		$a6 = "localhost" fullword wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Skreweverything_Swift {
    meta:
		description = "It is a simple and easy to use keylogger for macOS written in Swift."
		author = "@mimeframe"
		id = "a4918bc3-d3f0-59f4-894f-fd34ee944fac"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/SkrewEverything/Swift-Keylogger"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_skreweverything_swift.yara#L1-L15"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "f400b8ec392417e7443e82a2c2a9adfc868b9795aa1fb29f91d228f6f94efd13"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "Can't create directories!" wide ascii
		$a2 = "Can't create manager" wide ascii
		$a3 = "Can't open HID!" wide ascii
		$a4 = "PRINTSCREEN" wide ascii
		$a5 = "LEFTARROW" wide ascii

	condition:
		4 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Giacomolaw {
    meta:
		description = "A simple keylogger for macOS."
		author = "@mimeframe"
		id = "81fcf792-a0a9-5b97-a71c-4c517a7b910c"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/GiacomoLaw/Keylogger"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_giacomolaw.yara#L1-L13"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "45ca583c07b8593ed716306ae6f80eef1c3fc5652aed739454fa8007fae929b4"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "ERROR: Unable to access keystroke log file. Please make sure you have the correct permissions." wide ascii
		$a2 = "ERROR: Unable to create event tap." wide ascii
		$a3 = "Keystrokes are now being recorded" wide ascii

	condition:
		2 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Exploit_Tpwn {
    meta:
		description = "tpwn exploits a null pointer dereference in XNU to escalate privileges to root."
		author = "@mimeframe"
		id = "b69c4e1c-554e-5553-9b21-6cdf33aff24e"
		date = "2017-09-14"
		modified = "2017-09-14"
		reference = "https://www.rapid7.com/db/modules/exploit/osx/local/tpwn"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_exploit_tpwn.yara#L1-L14"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "f864d8c137746edd50526b1d3d95a7335f776cf1473d2d2ea28856dbc515dd9f"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "[-] Couldn't find a ROP gadget, aborting." wide ascii
		$a2 = "leaked kaslr slide," wide ascii
		$a3 = "didn't get root, but this system is vulnerable." wide ascii
		$a4 = "Escalating privileges! -qwertyoruiop" wide ascii

	condition:
		2 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Manwhoami_Icloudcontacts {
    meta:
		description = "Pulls iCloud Contacts for an account. No dependencies. No user notification."
		author = "@mimeframe"
		id = "b6595540-7f89-5764-b34e-d32c1a377b6c"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/manwhoami/iCloudContacts"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_manwhoami_icloudcontacts.yara#L1-L14"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "0c5b81454b26de91f5ad126b24f10397e1da5d8561b0bf22c5df128753df0ac2"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "https://setup.icloud.com/setup/authenticate/" wide ascii
		$a2 = "https://p04-contacts.icloud.com/" wide ascii
		$a3 = "HTTP Error 401: Unauthorized. Are you sure the credentials are correct?" wide ascii
		$a4 = "HTTP Error 404: URL not found. Did you enter a username?" wide ascii

	condition:
		3 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Macpmem {
    meta:
		description = "MacPmem enables read/write access to physical memory on macOS. Can be used by CSIRT teams and attackers."
		author = "@mimeframe"
		id = "4890598e-936c-5a4d-9004-88ff4fe57c49"
		date = "2017-08-11"
		modified = "2017-08-11"
		reference = "https://github.com/google/rekall/tree/master/tools/osx/MacPmem"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_macpmem.yara#L3-L22"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "d64b5a5423932211e3b72d949028f3f0ed1f1435e9584cffa947f2bd4846c29b"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "%s/MacPmem.kext" wide ascii
		$a2 = "The Pmem physical memory imager." wide ascii
		$a3 = "The OSXPmem memory imager." wide ascii
		$a4 = "These AFF4 Volumes will be loaded and their metadata will be parsed before the program runs." wide ascii
		$a5 = "Pmem driver version incompatible. Reported" wide ascii
		$a6 = "Memory access driver left loaded since you specified the -l flag." wide ascii
		$b1 = "Unloading MacPmem" wide ascii
		$b2 = "MacPmem load tag is" wide ascii

	condition:
		BINARYALERT_Macho_PRIVATE and 2 of ( $a* ) or all of ( $b* )
}
rule BINARYALERT_Hacktool_Macos_Juuso_Keychaindump {
    meta:
		description = "For reading OS X keychain passwords as root."
		author = "@mimeframe"
		id = "10ee6c24-db35-5178-9a40-92f5231948aa"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/juuso/keychaindump"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_juuso_keychaindump.yara#L1-L16"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "dd2fb6249fe4b7381e734ea3a308158159f7e79b39ba5c970241dcd66436d669"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "[-] Too many candidate keys to fit in memory" wide ascii
		$a2 = "[-] Could not allocate memory for key search" wide ascii
		$a3 = "[-] Too many credentials to fit in memory" wide ascii
		$a4 = "[-] The target file is not a keychain file" wide ascii
		$a5 = "[-] Could not find the securityd process" wide ascii
		$a6 = "[-] No root privileges, please run with sudo" wide ascii

	condition:
		4 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Caseyscarborough {
    meta:
		description = "A simple and easy to use keylogger for macOS."
		author = "@mimeframe"
		id = "82d9ff7e-b475-5888-82e1-f65c286a9cde"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/caseyscarborough/keylogger"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_caseyscarborough.yara#L1-L14"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "d97fbfefe027a26ec998743b811734e62423e8a5ba4e11d516dcfc9e4831d296"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "/var/log/keystroke.log" wide ascii
		$a2 = "ERROR: Unable to create event tap." wide ascii
		$a3 = "Keylogging has begun." wide ascii
		$a4 = "ERROR: Unable to open log file. Ensure that you have the proper permissions." wide ascii

	condition:
		2 of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_B4Rsby_Swiftlog {
    meta:
		description = "Dirty user level command line keylogger hacked together in Swift."
		author = "@mimeframe"
		id = "b1ae8284-04a0-5818-9997-0e31eb51ed2b"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/b4rsby/SwiftLog"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_b4rsby_swiftlog.yara#L1-L11"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "c66dcab2da0e543198f97ca104c13533c8950d10b6f7cbd3f906348d0f8c45ff"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "You need to enable the keylogger in the System Prefrences" wide ascii

	condition:
		all of ( $a* )
}
rule BINARYALERT_Hacktool_Macos_Keylogger_Eldeveloper_Keystats {
    meta:
		description = "A simple keylogger for macOS."
		author = "@mimeframe"
		id = "7fddb502-ae2d-5e14-95f5-115498fa5926"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/ElDeveloper/keystats"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/hacktool/macos/hacktool_macos_keylogger_eldeveloper_keystats.yara#L1-L13"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "c73f5ca2ba0a1bde7c1f9b96173938e40511e12f875c4d850d6d498c63e89385"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "YVBKeyLoggerPerishedNotification" wide ascii
		$a2 = "YVBKeyLoggerPerishedByLackOfResponseNotification" wide ascii
		$a3 = "YVBKeyLoggerPerishedByUserChangeNotification" wide ascii

	condition:
		2 of ( $a* )
}
rule BINARYALERT_Malware_Macos_Macspy : FILE {
    meta:
		description = "macSpy is a malware-as-a-service (MaaS) product advertised as the most sophisticated Mac spyware ever"
		author = "AlienVault Labs"
		id = "5f9a5ed5-a982-552c-a6df-326228eaf459"
		date = "2017-08-11"
		modified = "2017-08-11"
		reference = "https://www.alienvault.com/blogs/labs-research/macspy-os-x-rat-as-a-service"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_macspy.yara#L3-L17"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		hash = "6c03e4a9bcb9afaedb7451a33c214ae4"
		logic_hash = "f04648860c9602e43516113000908008847dacfbe189d79e13737bcd034b68a0"
		score = 75
		quality = 80
		tags = "FILE"

	strings:
		$header0 = {cf fa ed fe}
		$header1 = {ce fa ed fe}
		$header2 = {ca fe ba be}
		$c1 = { 76 31 09 00 76 32 09 00 76 33 09 00 69 31 09 00 69 32 09 00 69 33 09 00 69 34 09 00 66 31 09 00 66 32 09 00 66 33 09 00 66 34 09 00 74 63 3A 00 }

	condition:
		($header0 at 0 or $header1 at 0 or $header2 at 0 ) and $c1
}
rule BINARYALERT_Malware_Macos_Bella {
    meta:
		description = "Bella is a pure python post-exploitation data mining tool & remote administration tool for macOS."
		author = "@mimeframe"
		id = "ca4ab508-8c97-5307-9aaf-db10cfd6ab35"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/Trietptm-on-Security/Bella"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_bella.yara#L1-L22"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "b9c063b5ec8604958d3417ec8640da4314ebcf60ee55413a2f6fa8d138311614"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "Verified! [2FV Enabled] Account ->" wide ascii
		$a2 = "There is no root shell to perform this command. See [rooter] manual entry." wide ascii
		$a3 = "Attempt to escalate Bella to root through a variety of attack vectors." wide ascii
		$a4 = "BELLA IS NOW RUNNING. CONNECT TO BELLA FROM THE CONTROL CENTER." wide ascii
		$b1 = "user_pass_phish" fullword wide ascii
		$b2 = "bella_info" fullword wide ascii
		$b3 = "get_root" fullword wide ascii
		$c1 = "Please specify a bella server." wide ascii
		$c2 = "What port should Bella connect on [Default is 4545]:" wide ascii

	condition:
		any of ( $a* ) or all of ( $b* ) or all of ( $c* )
}
rule BINARYALERT_Malware_Macos_Proton_Rat_Generic {
    meta:
		description = "No description has been set in the source file - BinaryAlert"
		author = "@mimeframe"
		id = "75cfaaff-e8d7-5cd4-953b-7d2011139725"
		date = "2017-08-11"
		modified = "2017-08-11"
		reference = "https://objective-see.com/blog/blog_0x1D.html"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_proton_rat_generic.yara#L3-L21"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		hash = "6a2d0c8b20efc3fa283176a4bc76d6fd"
		logic_hash = "b7d8660320564cba1d8e2d53d1fdc75509140c7e87a572b27931c62201df2d22"
		score = 75
		quality = 64
		tags = ""

	strings:
		$a1 = "SRWebSocket" nocase wide ascii
		$a2 = "SocketRocket" nocase wide ascii
		$b1 = "SSH tunnel not launched" nocase wide ascii
		$b2 = "SSH tunnel still running" nocase wide ascii
		$b3 = "SSH tunnel already launched" nocase wide ascii
		$b4 = "Entering interactive session." nocase wide ascii

	condition:
		BINARYALERT_Macho_PRIVATE and any of ( $a* ) and any of ( $b* )
}
rule BINARYALERT_Malware_Macos_Neoneggplant_Eggshell {
    meta:
		description = "EggShell is an iOS and macOS post exploitation surveillance pentest tool written in Python."
		author = "@mimeframe"
		id = "274a34cc-9403-50e6-aa64-683a41bc30e6"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/neoneggplant/EggShell"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_neoneggplant_eggshell.yara#L1-L24"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "34906db9398313ccb84e67bd98e94324c628aefe3efa6ba3cca2df042b42cbe7"
		score = 50
		quality = 80
		tags = ""

	strings:
		$a1 = "Created By Lucas Jackson (@neoneggplant)" wide ascii
		$a2 = "SET LHOST (Leave blank for" wide ascii
		$a3 = "SET LPORT (Leave blank for" wide ascii
		$b1 = "/tmp/.esplog" wide ascii
		$b2 = "spGHbigdxMBJpbOCAr3rnS3inCdYQyZV" wide ascii
		$b3 = "keylogclear" wide ascii
		$b4 = "getpasscode" wide ascii
		$c1 = "spGHbigdxMBJpbOCAr3rnS3inCdYQyZV" wide ascii
		$c2 = "getfacebook" wide ascii
		$c3 = "type is eggsu" wide ascii
		$c4 = "rmpersistence" wide ascii

	condition:
		all of ( $a* ) or 3 of ( $b* ) or 3 of ( $c* )
}
rule BINARYALERT_Malware_Macos_Marten4N6_Evilosx {
    meta:
		description = "EvilOSX is a pure python, post-exploitation, RAT (Remote Administration Tool) for macOS / OSX."
		author = "@mimeframe"
		id = "2b2e62ca-f95c-55c5-aaf6-985aab49dfbb"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://github.com/Marten4n6/EvilOSX"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_marten4n6_evilosx.yara#L1-L16"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		logic_hash = "3402ebf34fd507d0c317416bf77bb3d51b67c8b0f099ce68d15ade6a6a2e302a"
		score = 75
		quality = 80
		tags = ""

	strings:
		$a1 = "icloud_phish_stop" fullword wide ascii
		$a2 = "icloud_contacts" fullword wide ascii
		$a3 = "itunes_backups" fullword wide ascii
		$a4 = "chrome_passwords" fullword wide ascii
		$a5 = "Starting EvilOSX..." wide ascii

	condition:
		4 of ( $a* )
}
rule BINARYALERT_Malware_Macos_Apt_Sofacy_Xagent {
    meta:
		description = "sofacy xagent for macOS"
		author = "@mimeframe"
		id = "91bef771-2ef1-58f6-ae01-3bdde4cc003c"
		date = "2017-09-12"
		modified = "2017-09-12"
		reference = "https://blog.malwarebytes.com/cybercrime/2017/03/two-new-mac-backdoors-discovered/"
		source_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/rules/public/malware/macos/malware_macos_apt_sofacy_xagent.yara#L3-L62"
		license_url = "https://github.com/airbnb/binaryalert//blob/a9c0f06affc35e1f8e45bb77f835b92350c68a0b/LICENSE"
		hash = "4fe4b9560e99e33dabca553e2eeee510"
		logic_hash = "d4b1096e4aeb8382e5abf93d3ecf71cd6ae2ed7afbc9a38549a2fc2739539674"
		score = 75
		quality = 55
		tags = ""

	strings:
		$a1 = "remoteShell" ascii wide
		$a2 = "getInfoOSX" ascii wide
		$a3 = "ftpUpload" ascii wide
		$a4 = "startUploading" ascii wide
		$a5 = "deleteFile:" ascii wide
		$a6 = "executeShellCommand" ascii wide
		$a7 = "getFirefoxPassword" ascii wide
		$a8 = "generateRandomPathAndName" ascii wide
		$a9 = "createCryptPacket" ascii wide
		$a10 = "CameraShot" ascii wide
		$a11 = "7Cryptor" ascii wide
		$a12 = "8ICryptor" ascii wide
		$a13 = "Keylogger" ascii wide
		$a14 = "BootXLoader" ascii wide
		$a15 = "InjectApp" ascii wide
		$b1 = "/Project/XAgentOSX/" ascii wide
		$b2 = "XLoader_OSX" fullword ascii wide
		$b3 = "<span class='keylog_user_keys'>" ascii wide
		$b4 = "<span class='keylog_process'>" ascii wide
		$b5 = "<span class='keylog_spec_key'>" ascii wide
		$b6 = "<font size=4 color=red><pre>Stop take screenshot</pre></font>" ascii wide
		$c1 = "http://23.227.196.215/" ascii wide
		$c2 = "http://apple-iclods.org/" ascii wide
		$c3 = "http://apple-checker.org/" ascii wide
		$c4 = "http://apple-uptoday.org/" ascii wide
		$c5 = "http://apple-search.info" ascii wide
		$d1 = "watch/?" fullword ascii wide
		$d2 = "search/?" fullword ascii wide
		$d3 = "find/?" fullword ascii wide
		$d4 = "results/?" fullword ascii wide
		$d5 = "open/?" fullword ascii wide
		$d6 = "search/?" fullword ascii wide
		$d7 = "close/?" fullword ascii wide
		$e1 = "itwm=" fullword ascii wide
		$e2 = "text=" fullword ascii wide
		$e3 = "from=" fullword ascii wide
		$e4 = "itwm=" fullword ascii wide
		$e5 = "ags=" fullword ascii wide
		$e6 = "btnG=" fullword ascii wide
		$e7 = "oprnd=" fullword ascii wide
		$e8 = "itwm=" fullword ascii wide
		$e9 = "utm=" fullword ascii wide
		$e10 = "channel=" fullword ascii wide

	condition:
		BINARYALERT_Macho_PRIVATE and ( 5 of ( $a* ) or any of ( $b* ) or any of ( $c* ) or 4 of ( $d* ) or 5 of ( $e* ) )
}
rule DEADBITS_Crescentcore_DMG : INSTALLER MACOSMALWARE FILE {
    meta:
		description = "No description has been set in the source file - DeadBits"
		author = "Adam Swanda"
		id = "2bd03287-3f10-50b0-9560-4c88644f5b20"
		date = "2019-07-18"
		modified = "2019-07-22"
		reference = "https://github.com/deadbits/yara-rules"
		source_url = "https://github.com/deadbits/yara-rules//blob/d002f7ecee23e09142a3ac3e79c84f71dda3f001/rules/crescentcore_dmg.yara#L1-L48"
		license_url = "N/A"
		logic_hash = "819f01fdacea1e95f0f4d4f8e59ebae97ff9489a1be2c60e33253580a8f9e418"
		score = 75
		quality = 51
		tags = "INSTALLER, MACOSMALWARE, FILE"
		Author = "Adam M. Swanda"

	strings:
		$header0 = "__PAGEZERO" ascii
		$header1 = "__TEXT" ascii
		$path0 = "/Users/mehdi/Desktop/RED MOON/Project/WaningCrescent/WaningCrescent/" ascii
		$install0 = ".app\" /Applications" ascii fullword
		$install1 = "open \"/Applications/" ascii fullword
		$str1 = /Flash_Player\dVirusMp/ ascii
		$str2 = /Flash_Player\dAntivirus33/ ascii
		$str3 = /Flash_Player\d{2}Armageddon/ ascii
		$str4 = /Flash_Player\d{2}Armageddon\w\dapocalypsyy/
		$str5 = /Flash_Player\d{2}Armageddon\w\ddoomsdayyy/
		$str6 = /SearchModel\w\dbrowser/
		$str8 = /SearchModel\w\dcountry/
		$str9 = /SearchModel\w\dhomepage/
		$str10 = /SearchModel\w\dthankyou/
		$str11 = /SearchModel\w\dinterrupt/
		$str12 = /SearchModel\w\dsearch/
		$str13 = /SearchModel\w\dsuccess/
		$str14 = /SearchModel\w\d{2}carrierURL/

	condition:
		( uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xbebafeca ) and $header0 and $header1 and ( ( $path0 and ( any of ( $install* ) ) ) or ( 5 of ( $str* ) ) ) or all of them
}
rule FIREEYE_RT_APT_Backdoor_Macos_GORAT_1 : FILE {
    meta:
		description = "This rule is looking for specific strings associated with network activity found within the MacOS generated variant of GORAT"
		author = "FireEye"
		id = "4646eadb-7acf-582f-9ad6-00f012ceed8a"
		date = "2020-12-08"
		modified = "2020-12-09"
		reference = "https://github.com/mandiant/red_team_tool_countermeasures/"
		source_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/rules/REDFLARE (Gorat)/production/yara/APT_Backdoor_MacOS_GORAT_1.yar#L4-L19"
		license_url = "https://github.com/mandiant/red_team_tool_countermeasures//blob/3561b71724dbfa3e2bb78106aaa2d7f8b892c43b/LICENSE.txt"
		hash = "68acf11f5e456744262ff31beae58526"
		logic_hash = "2df5f87d44968670511880d21ad184779d0561c7c426a5d6426bcefd0904a9b7"
		score = 75
		quality = 75
		tags = "FILE"
		rev = 3

	strings:
		$s1 = "SID1=%s" ascii wide
		$s2 = "http/http.dylib" ascii wide
		$s3 = "Mozilla/" ascii wide
		$s4 = "User-Agent" ascii wide
		$s5 = "Cookie" ascii wide

	condition:
		(( uint32( 0 ) == 0xBEBAFECA ) or ( uint32( 0 ) == 0xFEEDFACE ) or ( uint32( 0 ) == 0xFEEDFACF ) or ( uint32( 0 ) == 0xCEFAEDFE ) ) and all of them
}
rule ARKBIRD_SOLG_MAL_Milum_Jul_2021_1 : FILE {
    meta:
		description = "Detect Milum malware"
		author = "Arkbird_SOLG"
		id = "ba1cc56e-f6da-57db-a773-4823ae343e31"
		date = "2021-07-08"
		modified = "2021-07-08"
		reference = "https://securelist.com/wildpressure-targets-macos/103072/"
		source_url = "https://github.com/StrangerealIntel/DailyIOC/blob/a873ff1298c43705e9c67286f3014f4300dd04f7/2021-07-08/WildPressure/MAL_Milum_Jul_2021_1.yara#L1-L33"
		license_url = "N/A"
		hash = "7eafb957c2e715e06489a979a185f75d7a9d502223c8aba36e7b6b8ead7d03b2"
		hash = "86456ebf6b807e8253faf1262e7a2b673131c80174f6133b253b2e5f0da442a9"
		hash = "5e0226f37b861876ec38e4a1564a26e4af3022d869375bc0f09b8feea4cd9e1b"
		logic_hash = "4321051fdc9ab5f4ee12c4b505e4271df89b489067875eaf3d2cb670815f7e37"
		score = 75
		quality = 75
		tags = "FILE"
		tlp = "White"
		adversary = "WildPressure"

	strings:
		$s1 = { 52 00 4f 00 4f 00 54 00 5c 00 53 00 65 00 63 00 75 00 72 00 69 00 74 00 79 00 43 00 65 00 6e 00 74 00 65 00 72 00 32 00 00 00 00 00 53 00 65 00 6c 00 65 00 63 00 74 00 20 [3-7] 20 00 46 00 72 00 6f 00 6d 00 20 00 41 00 6e 00 74 00 69 00 56 00 69 00 72 00 75 00 73 00 50 00 72 00 6f 00 64 00 75 00 63 00 74 00 20 00 57 00 48 00 45 00 52 00 45 00 20 00 64 00 69 00 73 00 70 00 6c 00 61 00 79 00 4e 00 61 00 6d 00 65 00 20 00 3c 00 3e 00 27 00 57 00 69 00 6e 00 64 00 6f 00 77 00 73 00 20 00 44 00 65 00 66 00 65 00 6e 00 64 00 65 00 72 00 27 }
		$s2 = "c1VybCA9IHt1fQ0Kc1JlcXVlc3QgPSB7cH0NCkhUVFBQb3N0IHNVcmwsIHNSZXF1ZXN0DQpGdW5jdGlvbiBIVFRQUG9zdChzVXJsLCBzUmVxdWVzdCkNCiAgc2V0IG9IVFRQID0gQ3JlYXRlT2JqZWN0KCJNaWNyb3NvZnQuWE1MSFRUUCIpDQogIG9IVFRQLm9wZW4gIlBPU1QiLCBzVXJsLGZhbHNlDQogIG9IVFRQLnNldFJlcXVlc3RIZWFkZXIgIkNvbnRlbnQtVHlwZSIsICJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQiDQogIG9IVFRQLnNldFJlcXVlc3RIZWFkZXIgIkNvbnRlbnQtTGVuZ3RoIiwgTGVuKHNSZXF1ZXN0KQ0KICBvSFRUUC5zZW5kIHNSZXF1ZXN0DQogIFdzY3JpcHQuRWNobyBvSFRUUC5yZXNwb25zZVRleHQNCiAgSFRUUFBvc3QgPSBvSFRUUC5yZXNwb25zZVRleHQNCiBFbmQgRnVuY3Rpb24=" fullword ascii
		$s3 = { 46 49 4c 45 20 48 41 4e 44 45 4c 20 4e 4f 54 20 46 4f 55 4e 44 00 00 00 4e 4f 20 44 61 74 61 00 }
		$s4 = { 28 00 77 00 73 00 33 00 32 00 29 00 65 00 79 00 4a 00 73 00 62 00 32 00 35 00 6e 00 64 00 32 00 46 00 70 00 64 00 43 00 49 00 36 00 49 00 6a 00 }
		$s5 = { 55 8b ec 6a ff 68 [3] 00 64 a1 00 00 00 00 50 83 ec 24 a1 [3] 00 33 c5 89 45 f0 ?? 57 50 8d 45 f4 64 a3 00 00 00 00 [8] b9 0f 00 00 00 89 4e }
		$s6 = { 20 2f 63 20 [0-1] 46 4f 52 20 2f 6c 20 25 69 20 69 6e 20 28 31 2c 31 2c [1-4] 29 20 44 4f 20 49 46 20 4e 4f 54 20 45 58 49 53 54 20 22 00 22 29 }
		$s7 = { 83 c4 0c 8d 95 44 fe ff ff 52 c7 85 44 fe ff ff 14 01 00 00 ff 15 [3] 00 83 bd 48 fe ff ff 06 7d 17 bf [3] 00 89 bd ?? fe ff ff c7 85 ?? fe ff ff [3] 00 eb 1a c7 85 ?? fe ff ff [3] 00 8b bd ?? fe ff ff c7 85 ?? fe ff ff [3] 00 }
		$s8 = { 8b 45 08 50 68 bc 78 45 00 68 d0 78 45 00 8d 8d d0 fc ff ff 51 ff d6 83 c4 10 8b 3d a0 e0 44 00 8b 35 c4 e0 44 00 8d 64 }

	condition:
		uint16( 0 ) == 0x5a4d and filesize > 40KB and 5 of ( $s* )
}
rule VOLEXITY_Apt_Malware_Any_Dotnet_Aot_Plenet : VERDANTBAMBOO PLENET FILE MEMORY {
    meta:
		description = "Detect PLENET, a multiplatform malware compile with native AOT."
		author = "threatintel@volexity.com"
		id = "615d7c43-0128-5cfa-a080-6ece5d2dc029"
		date = "2025-09-22"
		modified = "2025-10-30"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-06-04 VerdantBamboo/rules.yar#L1-L31"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "eb141a43958802727a6c813452450c10b92704bea4474ee5fd87c0a1be326e2e"
		logic_hash = "67d8f7fbc2986b1068a9c557cf85ba83469e3fb7f2433bd10c7ad740a4b0e717"
		score = 75
		quality = 80
		tags = "VERDANTBAMBOO, PLENET, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20251104"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 12367
		version = 4

	strings:
		$str1 = "[!] Bad dat" wide
		$str2 = "[!] Connection error. Kill Pty" wide
		$str3 = "[!] Error : Plexor is nul" wide
		$str4 = "[!] Unkown message type" wide
		$str5 = "[*] Disposing.." wide
		$str6 = "Lack port ':" wide
		$str7 = "IPv6 port error ':" wide
		$str8 = "this.existingPipeGiven." wide
		$str9 = "port must within 0~6553" wide

	condition:
		4 of them
}
rule VOLEXITY_Apt_Malware_Golang_Brickstorm_B : VERDANTBAMBOO BRICKSTORM FILE MEMORY {
    meta:
		description = "Detection for the BRICKSTORM malware family."
		author = "threatintel@volexity.com"
		id = "b3b9ff26-56ab-5801-8905-0a304887b998"
		date = "2025-09-05"
		modified = "2026-06-09"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-06-04 VerdantBamboo/rules.yar#L56-L98"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "aa688682d44f0c6b0ed7f30b981a609100107f2d414a3a6e5808671b112d1878"
		logic_hash = "e91203a714a4bc9d1c70eae4670681e3f416257163cf44db20ad33380be5d39a"
		score = 75
		quality = 80
		tags = "VERDANTBAMBOO, BRICKSTORM, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20251104"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 12299
		version = 6

	strings:
		$method1 = "UnPackHeaderData"
		$method2 = "handleRelay"
		$method3 = "NewWebSocketClient"
		$method4 = "createDnsMessage"
		$method5 = "GetFileOwnerInfo"
		$err1 = "dns rcode: %v"
		$err2 = "readFull error"
		$err3 = "tagAuth error"
		$err4 = "error: Auth: %s"
		$ws1 = "<a style='text-decoration: none;'  href='javascript:history.go(-1);'><h5>Back</h5></a>"
		$ws2 = "Mon, 02 Jan 2006 15:04:05 GMT"
		$doh = "https://1.0.0.1/dns-queryhttps://1.1.1.1/dns-queryhttps://8.8.4.4/dns-queryhttps://8.8.8.8/dns-query"

	condition:
		4 of ( $method* ) or 3 of ( $err* ) or all of ( $ws* ) or ( $doh and 3 of ( $method* , $err* , $ws* , $doh ) )
}
rule VOLEXITY_Apt_Malware_Golang_Brickstorm : VERDANTBAMBOO BRICKSTORM FILE MEMORY {
    meta:
		description = "Detects the BRICKSTORM backdoor using common strings."
		author = "threatintel@volexity.com"
		id = "25775278-5115-5873-957f-9c5d0c8e4f5e"
		date = "2025-09-04"
		modified = "2025-10-30"
		reference = "https://blog.nviso.eu/wp-content/uploads/2025/04/NVISO-BRICKSTORM-Report.pdf"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-06-04 VerdantBamboo/rules.yar#L100-L136"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "40d264cf9c73923932c3dfd52d20f46ff602be3fea8dc6ecc71aca46e6067bf5"
		hash = "e981fc4eaaa6417e6034e21438e55c0360773674a6fc0b63c1b95026449e5254"
		logic_hash = "39e3403d90ad67072ae631273e89fe059ec48906ce1d57fe1afbb91304dc84f3"
		score = 75
		quality = 80
		tags = "VERDANTBAMBOO, BRICKSTORM, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20251104"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 12298
		version = 7

	strings:
		$dns1 = "https://1.1.1.1/dns-query" ascii
		$dns2 = "https://8.8.4.4/dns-query" ascii
		$dns3 = "https://8.8.8.8/dns-query" ascii
		$pack1 = "wsshell/core" ascii
		$pack2 = "wssoft/core" ascii
		$s1 = "github.com/hashicorp/yamux" ascii
		$s2 = "winbindd:" ascii
		$s3 = "WEE1=true" ascii
		$s4 = "WEE2=true" ascii

	condition:
		all of ( $dns* ) and all of ( $s* ) and any of ( $pack* )
}
rule VOLEXITY_Apt_Malware_Py_Agentpsd : VERDANTBAMBOO AGENTPSD MEMORY {
    meta:
		description = "Detection for AgentPSD, a python-based malware typically delivered within PyInstaller-built binaries."
		author = "threatintel@volexity.com"
		id = "4a7d531f-926d-557e-b2a0-d4f103e9c63a"
		date = "2025-09-05"
		modified = "2025-10-30"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-06-04 VerdantBamboo/rules.yar#L137-L171"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "ee41e06ed96182ce80cd4544a6abd5d7719c4a5c0e5ddb266a83842d39b99b0a"
		logic_hash = "dd0b957bc2a61ddebd392b86b35bae8c1052a285fa31ccd700e580c2ad9cce59"
		score = 75
		quality = 80
		tags = "VERDANTBAMBOO, AGENTPSD, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "memory"
		severity = "critical"
		report1 = "TIB-20251104"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 12297
		version = 5

	strings:
		$s1 = "g_strPhpUrl" ascii
		$s2 = "g_nSleepMinits" ascii
		$s3 = "g_nDuringTime" ascii
		$func1 = "startwork" ascii
		$func2 = "ifrunning" ascii
		$func3 = "getsysinfo" ascii
		$func4 = "getcmdfromweb" ascii
		$func5 = "ParseCmdFromResponse" ascii
		$func6 = "PostDataToServer" ascii
		$func7 = "DealWithBuildinCommand" ascii
		$func8 = "PostBuildinResultToWeb" ascii

	condition:
		2 of ( $s* ) or 4 of ( $func* )
}
rule VOLEXITY_Apt_Webshell_Java_Orangetail_B : UTA0533 ORANGETAIL FILE MEMORY {
    meta:
		description = "Detection for the accept logic of ORANGETAIL, a custom Java webshell used by UTA0533."
		author = "threatintel@volexity.com"
		id = "e9f19175-ea33-5eea-8663-91fc805306bb"
		date = "2026-07-06"
		modified = "2026-07-14"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-07-17 SonicWall/rules.yar#L1-L25"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "1e1e68bbb899450a57274a8b12082ed4e2040a2aae77014f20431689d2b4edee"
		hash = "ea9154e374e4f77bc2cf54282e23543573980342a85bc888cb23f20b8bbba081"
		logic_hash = "e5ed25fb820dc4a18c374936c36d4321e2aba72d8b640cdb0d81abd764786918"
		score = 75
		quality = 80
		tags = "UTA0533, ORANGETAIL, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20260714B"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 13240
		version = 6

	strings:
		$s1 = ".equals($1.getHeader(\"User-Agent\"))) {  javax.servlet.jsp.JspFactory" ascii
		$s2 = " $2.setStatus(404);  $2.setContentLength(0);  $2.flushBuffer();  return;" ascii

	condition:
		all of them
}
rule VOLEXITY_Apt_Webshell_Java_Orangetail : UTA0533 ORANGETAIL FILE MEMORY {
    meta:
		description = "Detection for ORANGETAIL, a custom Java webshell used by UTA0533."
		author = "threatintel@volexity.com"
		id = "5bbffb5f-0917-57e4-a7d4-f5c770b5d253"
		date = "2026-07-06"
		modified = "2026-07-14"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-07-17 SonicWall/rules.yar#L26-L53"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "ea9154e374e4f77bc2cf54282e23543573980342a85bc888cb23f20b8bbba081"
		logic_hash = "1a495df2bc13b1c2c61315d76d66b150452b923afa5847121429fa8ae9788a7b"
		score = 75
		quality = 80
		tags = "UTA0533, ORANGETAIL, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20260714B"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 13239
		version = 5

	strings:
		$s1 = "agentmain called args="
		$s2 = "tryInject="
		$s3 = "agentmain ex:"
		$s4 = "javassist="
		$s5 = "tryInject exception"
		$s6 = "found loaded class:"

	condition:
		4 of ( $s* )
}
rule VOLEXITY_Apt_Malware_Any_Uta0533_Ua : UTA0533 FILE MEMORY {
    meta:
		description = "Identify any blob containing a bogus user-agent used in different components of an attack attributed to UTA0533."
		author = "threatintel@volexity.com"
		id = "c13dafb2-b2c3-5988-91dd-0345ef60086c"
		date = "2026-07-06"
		modified = "2026-07-14"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2026/2026-07-17 SonicWall/rules.yar#L54-L76"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "8c470301dcb7278f73e622f1950073567b34011c64b60cdfbb0f89803923a5a3"
		logic_hash = "d4c0322080e853f5c5d495af05d43eaf3d375af6905e795cef718dec639a7092"
		score = 75
		quality = 80
		tags = "UTA0533, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		report1 = "TIB-20260714B"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 13237
		version = 3

	strings:
		$s1 = "Mozilla/6.0 (Windows NT 11.0; Win64; x64) AppleWebKit/1537.136 (KHTML, like Gecko) Chrome/149.0.0.1 Safari/1537.136" ascii

	condition:
		$s1
}
rule VOLEXITY_Webshell_Jsp_Converge : FILE MEMORY CVE_2022_26134 {
    meta:
		description = "Detects CONVERGE - a file upload webshell observed in incident involving compromise of Confluence server via CVE-2022-26134."
		author = "threatintel@volexity.com"
		id = "2a74678e-cb00-567c-a2e0-2e095f3e5ee8"
		date = "2022-06-01"
		modified = "2024-09-20"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-06-02 Active Exploitation Of Confluence 0-day/indicators/yara.yar#L1-L21"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		logic_hash = "bb48516342eddd48c35e6db0eb74f95e116dc723503552b99ba721b5bdb391e5"
		score = 75
		quality = 80
		tags = "FILE, MEMORY, CVE-2022-26134"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6788
		version = 5

	strings:
		$s1 = "if (request.getParameter(\"name\")!=null && request.getParameter(\"name\").length()!=0){" ascii

	condition:
		$s1
}
rule VOLEXITY_Webshell_Java_Realcmd : FILE MEMORY {
    meta:
		description = "Detects the RealCMD webshell, one of the payloads for BEHINDER."
		author = "threatintel@volexity.com"
		id = "60b30ccc-bcfa-51e6-a3f5-88037d19213e"
		date = "2022-06-01"
		modified = "2024-07-30"
		reference = "https://github.com/Freakboy/Behinder/blob/master/src/main/java/vip/youwe/sheller/payload/java/RealCMD.java"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-06-02 Active Exploitation Of Confluence 0-day/indicators/yara.yar#L61-L84"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "a9a30455d6f3a0a8cd0274ae954aa41674b6fd52877fafc84a9cb833fd8858f6"
		logic_hash = "e09f2a23674fd73296dd4d1fabf1a2c812bfe69ff02abc96a4be35af6a18e512"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6786
		version = 4

	strings:
		$fn1 = "runCmd" wide ascii fullword
		$fn2 = "RealCMD" ascii wide fullword
		$fn3 = "buildJson" ascii wide fullword

	condition:
		all of ( $fn* )
}
rule VOLEXITY_Apt_Malware_Js_Sharpext : SHARPPINE FILE MEMORY {
    meta:
		description = "A malicious Chrome browser extension used by the SharpPine threat actor to steal Gmail data from a victim."
		author = "threatintel@volexity.com"
		id = "61b5176a-ff73-5fce-bc70-c9e09bb5afed"
		date = "2021-09-14"
		modified = "2025-05-21"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-07-28 SharpTongue SharpTongue Deploys Clever Mail-Stealing Browser Extension SHARPEXT/yara.yar#L1-L52"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "1c9664513fe226beb53268b58b11dacc35b80a12c50c22b76382304badf4eb00"
		hash = "6025c66c2eaae30c0349731beb8a95f8a5ba1180c5481e9a49d474f4e1bb76a4"
		hash = "6594b75939bcdab4253172f0fa9066c8aee2fa4911bd5a03421aeb7edcd9c90c"
		logic_hash = "0ed58c8646582ee36aeac650fac02d1e4962d45c0f6a24783c021d9267bed192"
		score = 75
		quality = 80
		tags = "SHARPPINE, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 5916
		version = 5

	strings:
		$s1 = "\"mode=attach&name=\"" ascii
		$s2 = "\"mode=new&mid=\"" ascii
		$s3 = "\"mode=attlist\"" ascii
		$s4 = "\"mode=list\"" ascii
		$s5 = "\"mode=domain\"" ascii
		$s6 = "\"mode=black\"" ascii
		$s7 = "\"mode=newD&d=\"" ascii
		$mark1 = "chrome.runtime.onMessage.addListener" ascii
		$mark2 = "chrome.webNavigation.onCompleted.addListener" ascii
		$enc1 = "function BSue(string){" ascii
		$enc2 = "function BSE(input){" ascii
		$enc3 = "function bin2hex(byteArray)" ascii
		$xhr1 = ".send(\"mode=cd1" ascii
		$xhr2 = ".send(\"mode=black" ascii
		$xhr3 = ".send(\"mode=domain" ascii
		$xhr4 = ".send(\"mode=list" ascii
		$manifest1 = "\"description\":\"advanced font\"," ascii
		$manifest2 = "\"scripts\":[\"bg.js\"]" ascii
		$manifest3 = "\"devtools_page\":\"dev.html\"" ascii

	condition:
		(5 of ( $s* ) and all of ( $mark* ) ) or all of ( $enc* ) or 3 of ( $xhr* ) or 2 of ( $manifest* )
}
rule VOLEXITY_Apt_Delivery_Office_Macro_Lazypine_Jeus : LAZYPINE FILE {
    meta:
		description = "Detects malicious documents used by LazyPine in a campaign dropping the AppleJeus malware."
		author = "threatintel@volexity.com"
		id = "f9a92f47-aa1d-56ea-ac59-47cc559f379f"
		date = "2022-11-02"
		modified = "2025-05-21"
		reference = "https://github.com/volexity/threat-intel"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-12-01 Buyer Beware - Fake Cryptocurrency Applications Serving as Front for AppleJeus Malware/yara.yar#L141-L165"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "17e6189c19dedea678969e042c64de2a51dd9fba69ff521571d63fd92e48601b"
		logic_hash = "54d5396b889a45d81122301eadf77f73135937fbe9647ad60491ac7856faf5ad"
		score = 75
		quality = 80
		tags = "LAZYPINE, FILE"
		os = "all"
		os_arch = "all"
		scan_context = "file"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 8490
		version = 7

	strings:
		$s1 = "0M8R4K" ascii
		$s2 = "bin.base64" ascii
		$s3 = "dragon" ascii
		$s4 = "Workbook_Open" ascii

	condition:
		all of ( $s* )
}
rule VOLEXITY_Malware_Golang_Pantegana : FILE MEMORY {
    meta:
		description = "Detects PANTEGANA, a Golang backdoor used by a range of threat actors due to its public availability."
		author = "threatintel@volexity.com"
		id = "b6154165-68e0-5986-a0cf-5631d369c230"
		date = "2022-03-30"
		modified = "2025-03-21"
		reference = "https://github.com/elleven11/pantegana"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-06-15 DriftingCloud - Zero-Day Sophos Firewall Exploitation and an Insidious Breach/indicators/yara.yar#L90-L120"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "8297c99391aae918f154077c61ea94a99c7a339166e7981d9912b7fdc2e0d4f0"
		logic_hash = "791a664a6b4b98051cbfacb451099de085cbab74d73771709377ab68a5a23d2b"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "high"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6631
		version = 3

	strings:
		$s1 = "RunFingerprinter" ascii
		$s2 = "SendSysInfo" ascii
		$s3 = "ExecAndGetOutput" ascii
		$s4 = "RequestCommand" ascii
		$s5 = "bindataRead" ascii
		$s6 = "RunClient" ascii
		$magic = "github.com/elleven11/pantegana" ascii

	condition:
		5 of ( $s* ) or $magic
}
rule VOLEXITY_Malware_Any_Pupyrat_B : FILE MEMORY {
    meta:
		description = "Detects the PUPYRAT malware family, a cross-platform RAT written in Python."
		author = "threatintel@volexity.com"
		id = "ec8d0448-f47d-5c6e-bcf9-8f40ae83a96f"
		date = "2022-04-07"
		modified = "2025-03-21"
		reference = "https://github.com/n1nj4sec/pupy"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-06-15 DriftingCloud - Zero-Day Sophos Firewall Exploitation and an Insidious Breach/indicators/yara.yar#L121-L158"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "7474a6008b99e45686678f216af7d6357bb70a054c6d9b05e1817c8d80d536b4"
		logic_hash = "f5b5f35ee783ff1163072591c6d48a85894729156935650a0fd166ae22a2ea00"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6689
		version = 4

	strings:
		$elf1 = "LD_PRELOAD=%s HOOK_EXIT=%d CLEANUP=%d exec %s 1>/dev/null 2>/dev/null" ascii
		$elf2 = "reflective_inject_dll" fullword ascii
		$elf3 = "ld_preload_inject_dll" fullword ascii
		$pupy1 = "_pupy.error" ascii
		$pupy2 = "pupy://" ascii
		$s1 = "Args not passed" ascii
		$s2 = "Too many args" ascii
		$s3 = "Can't execute" ascii
		$s4 = "mexec:stdin" ascii
		$s5 = "mexec:stdout" ascii
		$s6 = "mexec:stderr" ascii
		$s7 = "LZMA error" ascii

	condition:
		any of ( $elf* ) or all of ( $pupy* ) or all of ( $s* )
}
rule VOLEXITY_Apt_Malware_Macos_Gimmick : STORMBAMBOO FILE MEMORY {
    meta:
		description = "Detects the macOS port of the GIMMICK malware."
		author = "threatintel@volexity.com"
		id = "3d485788-4aab-511b-a49e-5dc09d1950a9"
		date = "2021-10-18"
		modified = "2024-08-02"
		reference = "https://www.volexity.com/blog/2022/03/22/storm-cloud-on-the-horizon-gimmick-malware-strikes-at-macos/"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2022/2022-03-22 GIMMICK/indicators/yara.yar#L1-L59"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "2a9296ac999e78f6c0bee8aca8bfa4d4638aa30d9c8ccc65124b1cbfc9caab5f"
		logic_hash = "00fba9df2212874a45d44b3d098a7b76c97fcd53ff083c76b784d2b510a4a467"
		score = 75
		quality = 78
		tags = "STORMBAMBOO, FILE, MEMORY"
		os = "darwin"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6022
		version = 8

	strings:
		$s1 = "http://cgi1.apnic.net/cgi-bin/my-ip.php --connect-timeout 10 -m 20" wide ascii
		$json1 = "base_json" ascii wide
		$json2 = "down_json" ascii wide
		$json3 = "upload_json" ascii wide
		$json4 = "termin_json" ascii wide
		$json5 = "request_json" ascii wide
		$json6 = "online_json" ascii wide
		$json7 = "work_json" ascii wide
		$msg1 = "bash_pid: %d, FDS_CHILD: %d, FDS_PARENT: %d" ascii wide
		$msg2 = "pid %d is dead" ascii wide
		$msg3 = "exit with code %d" ascii wide
		$msg4 = "recv signal %d" ascii wide
		$cmd1 = "ReadCmdQueue" ascii wide
		$cmd2 = "read_cmd_server_timer" ascii wide
		$cmd3 = "enableProxys" ascii wide
		$cmd4 = "result_block" ascii wide
		$cmd5 = "createDirLock" ascii wide
		$cmd6 = "proxyLock" ascii wide
		$cmd7 = "createDirTmpItem" ascii wide
		$cmd8 = "dowfileLock" ascii wide
		$cmd9 = "downFileTmpItem" ascii wide
		$cmd10 = "filePathTmpItem" ascii wide
		$cmd11 = "uploadItems" ascii wide
		$cmd12 = "downItems" ascii wide
		$cmd13 = "failUploadItems" ascii wide
		$cmd14 = "failDownItems" ascii wide
		$cmd15 = "downloadCmds" ascii wide
		$cmd16 = "uploadFiles" ascii wide
		$cmd17 = "bash callback...." ascii wide

	condition:
		$s1 or 5 of ( $json* ) or 3 of ( $msg* ) or 9 of ( $cmd* )
}
rule VOLEXITY_Malware_Golang_Discordc2_Bmdyy_1 : FILE MEMORY {
    meta:
		description = "Detects a opensource malware available on github using strings in the binary. The DISGOMOJI malware family used by TransparentJasmine is based on this malware."
		author = "threatintel@volexity.com"
		id = "6816d264-4311-5e90-948b-2e27cdf0b720"
		date = "2024-03-28"
		modified = "2024-07-05"
		reference = "TIB-20240229"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-06-13 DISGOMOJI/indicators/rules.yar#L216-L243"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "de32e96d1f151cc787841c12fad88d0a2276a93d202fc19f93631462512fffaf"
		logic_hash = "22b3e5109d0738552fbc310344b2651ab3297e324bc883d5332c1e8a7a1df29b"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "high"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10390
		version = 3

	strings:
		$s1 = "File is bigger than 8MB" wide ascii
		$s2 = "Uploaded file to" wide ascii
		$s3 = "sess-%d" wide ascii
		$s4 = "Session *%s* opened" wide ascii
		$s5 = "%s%d_%dx%d.png" wide ascii

	condition:
		4 of them
}
rule VOLEXITY_Malware_Golang_Discordc2_Bmdyy : FILE MEMORY {
    meta:
		description = "Detects a opensource malware available on github using strings in the binary. DISGOMOJI used by TransparentJasmine is based on this malware."
		author = "threatintel@volexity.com"
		id = "1ddbf476-ba2d-5cbb-ad95-38e0ae8db71b"
		date = "2024-02-22"
		modified = "2024-07-05"
		reference = "https://github.com/bmdyy/discord-c2"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-06-13 DISGOMOJI/indicators/rules.yar#L244-L267"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "d9f29a626857fa251393f056e454dfc02de53288ebe89a282bad38d03f614529"
		logic_hash = "38b860a43b9937351f74b01983888f18ad101cbe66560feb7455d46b713eba0f"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10264
		version = 12

	strings:
		$s1 = "**IP**: %s\n**User**: %s\n**Hostname**: %s\n**OS**: %s\n**CWD**" wide ascii

	condition:
		$s1
}
rule VOLEXITY_Apt_Malware_Any_Reloadext_Plugin : STORMBAMBOO FILE MEMORY {
    meta:
		description = "Detection for RELOADEXT, a Google Chrome extension malware."
		author = "threatintel@volexity.com"
		id = "6c6c8bee-2a13-5645-89ef-779f00264fd9"
		date = "2024-02-23"
		modified = "2024-08-02"
		reference = "TIB-20240227"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-08-02 StormBamboo/rules.yar#L4-L36"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "9d0928b3cc21ee5e1f2868f692421165f46b5014a901636c2a2b32a4c500f761"
		logic_hash = "2b11f8fc5b6260ebf00bde83585cd7469709a4979ca579cdf065724bc15052fc"
		score = 75
		quality = 80
		tags = "STORMBAMBOO, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10282
		version = 4

	strings:
		$man1 = "Reload page with Internet Explorer compatible mode."
		$man2 = "\"http://*/*\""
		$code1 = ";chrome["
		$code2 = "XMLHttpRequest(),_"
		$code3 = "0x400*0x400"

	condition:
		all of ( $man* ) or ( #code1 > 8 and #code2 >= 2 and #code3 >= 2 )
}
rule VOLEXITY_Apt_Malware_Macos_Reloadext_Installer : STORMBAMBOO FILE MEMORY {
    meta:
		description = "Detect the RELOADEXT installer."
		author = "threatintel@volexity.com"
		id = "c65ea2b5-ab98-5693-92ea-05c0f1ea1e5b"
		date = "2024-02-23"
		modified = "2024-08-02"
		reference = "TIB-20240227"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-08-02 StormBamboo/rules.yar#L37-L62"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "07e3b067dc5e5de377ce4a5eff3ccd4e6a2f1d7a47c23fe06b1ededa7aed1ab3"
		logic_hash = "8688796839202d95ded15e10262a7a7c7cbbae4a332b60305402e5984005d452"
		score = 75
		quality = 80
		tags = "STORMBAMBOO, FILE, MEMORY"
		os = "darwin"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10281
		version = 2

	strings:
		$str1 = "/CustomPlug1n/"
		$str2 = "Chrome NOT installed."
		$str3 = "-f force kill Chrome"
		$str4 = "/*} &&cp -rf ${"

	condition:
		3 of them
}
rule VOLEXITY_Apt_Malware_Any_Macma_A : STORMBAMBOO FILE MEMORY {
    meta:
		description = "Detects variants of the MACMA backdoor, variants of MACMA have been discovered for macOS and android."
		author = "threatintel@volexity.com"
		id = "6ab45af1-41e5-53fc-9297-e2bc07ebf797"
		date = "2021-11-12"
		modified = "2024-08-02"
		reference = "https://blog.google/threat-analysis-group/analyzing-watering-hole-campaign-using-macos-exploits/"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-08-02 StormBamboo/rules.yar#L63-L111"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "cf5edcff4053e29cb236d3ed1fe06ca93ae6f64f26e25117d68ee130b9bc60c8"
		hash = "9b71fad3280cf36501fe110e022845b29c1fb1343d5250769eada7c36bc45f70"
		hash = "623f99cbe20af8b79cbfea7f485d47d3462d927153d24cac4745d7043c15619a"
		hash = "d599d7814adbab0f1442f5a10074e00f3a776ce183ea924abcd6154f0d068bb4"
		logic_hash = "7ebaff9fddf6491d6b1ed9ab14c1b87dc8df850536e55aa723d625a593b33ed7"
		score = 75
		quality = 53
		tags = "STORMBAMBOO, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		report1 = "TIB-20231221"
		report2 = "TIB-20240227"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 6114
		version = 9

	strings:
		$magic1 = "curl -o %s http://cgi1.apnic.net/cgi-bin/my-ip.php" fullword ascii
		$magic2 = "[FST%d]: WhyUserCancel UNKNOW: %d" fullword ascii
		$magic3 = "[FST%d]: wait C2 prepare ready TIMEOUT, fd: %d" fullword ascii
		$magic4 = "[FST%d]: wait C2 ack file content TIMEOUT, fd: %d" fullword ascii
		$magic5 = "[FST%d]: TIMER_CHECK_CANCEL WhyUserCancel UNKNOW: %d" fullword ascii
		$magic6 = "[FST%d]: encrypt file info key=%s, crc v1=0x%p, v2=0x%p" fullword ascii
		$s1 = "auto bbbbbaaend:%d path %s" fullword ascii
		$s2 = "0keyboardRecirderStopv" fullword ascii
		$s3 = "curl begin..." fullword ascii
		$s4 = "curl over!" fullword ascii
		$s5 = "kAgent fail" fullword ascii
		$s6 = "put !!!!" fullword ascii
		$s7 = "vret!!!!!! %d" fullword ascii
		$s8 = "save Setting Success" fullword ascii
		$s9 = "Start Filesyste Search." fullword ascii
		$s10 = "./SearchFileTool" fullword ascii
		$s11 = "put unknow exception in MonitorQueue" fullword ascii
		$s12 = "./netcfg2.ini" fullword ascii
		$s13 = ".killchecker_" fullword ascii
		$s14 = "./param.ini" fullword ascii

	condition:
		any of ( $magic* ) or 7 of ( $s* )
}
rule VOLEXITY_Apt_Malware_Py_Dustpan_Pyloader : STORMBAMBOO FILE MEMORY {
    meta:
		description = "Detects Python script used by KPlayer to update, modified by attackers to download a malicious payload."
		author = "threatintel@volexity.com"
		id = "446d2eef-c60a-50ed-9ff1-df86b6210dff"
		date = "2023-07-21"
		modified = "2024-08-02"
		reference = "TIB-20231221"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-08-02 StormBamboo/rules.yar#L236-L270"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		logic_hash = "bb3a70dad28181534e27abbbd618165652c137264bfd3726ae4480c642493a3b"
		score = 75
		quality = 80
		tags = "STORMBAMBOO, FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 9530
		version = 4

	strings:
		$s_1 = "def count_md5(src)"
		$s_2 = "urllib.request.urlretrieve(image_url,main)"
		$s_3 = "m1 != '4c8a326899272d2fe30e818181f6f67f'"
		$s_4 = "os.path.split(os.path.realpath(__file__))[0]"
		$s_5 = "r_v = os.system('curl '+ini_url+cc)"
		$s_6 = "b41ef5f591226a0d5adce99cb2e629d8"
		$s_7 = "1df495e7c85e59ad0de1b9e50912f8d0"
		$s_8 = "tasklist | findstr mediainfo.exe"
		$url_1 = "http://dl1.5kplayer.com/youtube/youtube_dl.png"
		$url_2 = "http://dl1.5kplayer.com/youtube/youtube.ini?fire="
		$path_1 = "C:\\\\ProgramData\\\\Digiarty\\\\mediainfo.exe"

	condition:
		3 of ( $s_* ) or any of ( $url_* ) or $path_1
}
rule VOLEXITY_Hacktool_Py_Pysoxy : FILE MEMORY {
    meta:
		description = "SOCKS5 proxy tool used to relay connections."
		author = "threatintel@volexity.com"
		id = "88094b55-784d-5245-9c40-b1eebf0e6e72"
		date = "2024-01-09"
		modified = "2024-01-09"
		reference = "TIB-20240109"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-01-10 Ivanti Connect Secure/indicators/yara.yar#L87-L114"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "e192932d834292478c9b1032543c53edfc2b252fdf7e27e4c438f4b249544eeb"
		logic_hash = "f73e9d3c2f64c013218469209f3b69fc868efafc151a7de979dde089bfdb24b2"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10065
		version = 3

	strings:
		$s1 = "proxy_loop" ascii
		$s2 = "connect_to_dst" ascii
		$s3 = "request_client" ascii
		$s4 = "subnegotiation_client" ascii
		$s5 = "bind_port" ascii

	condition:
		all of them
}
rule VOLEXITY_Apt_Malware_Macos_Vpnclient_Cc_Oct23 : CHARMINGCYPRESS FILE MEMORY {
    meta:
		description = "Detection for fake macOS VPN client used by CharmingCypress."
		author = "threatintel@volexity.com"
		id = "e0957936-dc6e-5de6-bb23-d0ef61655029"
		date = "2023-10-17"
		modified = "2023-10-27"
		reference = "TIB-20231027"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-02-13 CharmingCypress/rules.yar#L246-L272"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "11f0e38d9cf6e78f32fb2d3376badd47189b5c4456937cf382b8a574dc0d262d"
		hash = "31ca565dcbf77fec474b6dea07101f4dd6e70c1f58398eff65e2decab53a6f33"
		logic_hash = "da5e9be752648b072a9aaeed884b8e1729a14841e33ed6633a0aaae1f11bd139"
		score = 75
		quality = 80
		tags = "CHARMINGCYPRESS, FILE, MEMORY"
		os = "darwin,linux"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 9770
		version = 3

	strings:
		$s1 = "networksetup -setsocksfirewallproxystate wi-fi off" ascii
		$s2 = "networksetup -setsocksfirewallproxy wi-fi ___serverAdd___ ___portNum___; networksetup -setsocksfirewallproxystate wi-fi on" ascii
		$s3 = "New file imported successfully." ascii
		$s4 = "Error in importing the File." ascii

	condition:
		2 of ( $s* )
}
rule VOLEXITY_Apt_Malware_Charmingcypress_Openvpn_Configuration : CHARMINGCYPRESS FILE {
    meta:
		description = "Detection for a .ovpn file used in a malicious VPN client on victim machines by CharmingCypress."
		author = "threatintel@volexity.com"
		id = "f39b2d7c-f0c5-5623-a114-02ba32469e59"
		date = "2023-10-17"
		modified = "2023-10-27"
		reference = "TIB-20231027"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-02-13 CharmingCypress/rules.yar#L273-L298"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "d6d043973d8843a82033368c785c362f51395b1a1d475fa4705aff3526e15268"
		hash = "31ca565dcbf77fec474b6dea07101f4dd6e70c1f58398eff65e2decab53a6f33"
		logic_hash = "f4c5f13ac75504b14def9c37d3a41c6eea4c45845d4b54c50030b1f00691e4bf"
		score = 75
		quality = 80
		tags = "CHARMINGCYPRESS, FILE"
		os = "all"
		os_arch = "all"
		scan_context = "file"
		severity = "high"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 9769
		version = 3

	strings:
		$remote = "remote-cert-tls server" ascii
		$ip = "Ip: "
		$tls = "<tls_auth>"

	condition:
		all of them
}
rule VOLEXITY_Susp_Any_Jarischf_User_Path : FILE MEMORY {
    meta:
		description = "Detects paths embedded in samples in released projects written by Ferdinand Jarisch, a pentester in AISEC. These tools are sometimes used by attackers in real world intrusions."
		author = "threatintel@volexity.com"
		id = "062a6fdb-c516-5643-9c7c-deff32eeb95e"
		date = "2024-04-10"
		modified = "2024-04-15"
		reference = "TIB-20240412"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-04-12 Palo Alto Networks GlobalProtect/indicators/rules.yar#L59-L81"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "161fd76c83e557269bee39a57baa2ccbbac679f59d9adff1e1b73b0f4bb277a6"
		logic_hash = "574d5b1fadb91c39251600e7d73d4993d4b16565bd1427a0e8d6ed4e7905ab54"
		score = 50
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "high"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10424
		version = 4

	strings:
		$proj_1 = "/home/jarischf/"

	condition:
		any of ( $proj_* )
}
rule VOLEXITY_Hacktool_Golang_Reversessh_Fahrj : FILE MEMORY {
    meta:
		description = "Detects a reverse SSH utility available on GitHub. Attackers may use this tool or similar tools in post-exploitation activity."
		author = "threatintel@volexity.com"
		id = "332e323f-cb16-5aa2-8b66-f3d6d50d94f2"
		date = "2024-04-10"
		modified = "2024-04-12"
		reference = "TIB-20240412"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2024/2024-04-12 Palo Alto Networks GlobalProtect/indicators/rules.yar#L82-L116"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "161fd76c83e557269bee39a57baa2ccbbac679f59d9adff1e1b73b0f4bb277a6"
		logic_hash = "38b40cc7fc1e601da2c7a825f1c2eff209093875a5829ddd2f4c5ad438d660f8"
		score = 75
		quality = 80
		tags = "FILE, MEMORY"
		os = "all"
		os_arch = "all"
		scan_context = "file,memory"
		severity = "critical"
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"
		rule_id = 10423
		version = 5

	strings:
		$fun_1 = "createLocalPortForwardingCallback"
		$fun_2 = "createReversePortForwardingCallback"
		$fun_3 = "createPasswordHandler"
		$fun_4 = "createPublicKeyHandler"
		$fun_5 = "createSFTPHandler"
		$fun_6 = "dialHomeAndListen"
		$fun_7 = "createExtraInfoHandler"
		$fun_8 = "createSSHSessionHandler"
		$fun_9 = "createReversePortForwardingCallback"
		$proj_1 = "github.com/Fahrj/reverse-ssh"

	condition:
		any of ( $proj_* ) or 4 of ( $fun_* )
}
rule VOLEXITY_Apt_Mac_Iconic : UTA0040 {
    meta:
		description = "Detects the MACOS version of the ICONIC loader."
		author = "threatintel@volexity.com"
		id = "6d702ed3-e5b9-5324-a06b-507c9231cc00"
		date = "2023-03-30"
		modified = "2023-03-30"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/2023/2023-03-30 3CX/indicators/rules.yar#L32-L50"
		license_url = "https://github.com/volexity/threat-intel/blob/a7eaa9d97a5d0c193f4a3ac99a6239e6ccc211de/LICENSE.txt"
		hash = "a64fa9f1c76457ecc58402142a8728ce34ccba378c17318b3340083eeb7acc67"
		logic_hash = "7b689c3931632b01869ac2f21a1edca0a5ca9007299fe7cd16962d6866c27558"
		score = 75
		quality = 80
		tags = "UTA0040"
		memory_suitable = 1
		license = "See license at https://github.com/volexity/threat-intel/blob/main/LICENSE.txt"

	strings:
		$str1 = "3CX Desktop App" xor(1-255)
		$str2 = "__tutma=" xor(1-255)
		$str3 = "Mozilla/5.0" xor(1-255)

	condition:
		all of them
}
rule RUSSIANPANDA_Garystealer : FILE {
    meta:
		description = "Detects GaryStealer 1-3-2024"
		author = "RussianPanda"
		id = "4b0af30e-2cf1-539d-89fa-7e4e32cd6eab"
		date = "2024-01-03"
		modified = "2024-01-03"
		reference = "https://cybersecurity.att.com/blogs/labs-research/behind-the-scenes-jaskagos-coordinated-strike-on-macos-and-windows"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/790ec6378c8e8262a673603ef0172bedf0967d58/GaryStealer/garystealer-1-3-2024.yar#L1-L20"
		license_url = "N/A"
		hash = "6efa29a0f9d112cfbb982f7d9c0ddfe395b0b0edb885c2d5409b33ad60ce1435"
		logic_hash = "f71655d0cb237c08af9c298ec9eec1ae9bd1efd50e26d61afddf9056b6883a15"
		score = 75
		quality = 79
		tags = "FILE"

	strings:
		$s1 = {72 75 6e 74 69 6d 65 2e 67 6f 70 61 6e 69 63}
		$s2 = {4c 6f 63 61 6c 20 49 50 20 41 64 64 72 65 73 73 65 73 3a 5b 70 69 63 6b 2d 66 69 72 73 74 2d 6c 62 20 25 70 5d}
		$s3 = {70 65 72 73 69 73 74 61 6E 63 65 20 63 72 65 61 74 65 64}
		$s4 = {C7 40 28 ?? 00 00 00}

	condition:
		uint16( 0 ) == 0x5A4D and 3 of ( $s* ) and filesize < 20MB and #s4 > 2
}
rule RUSSIANPANDA_Atomic_Stealer : FILE {
    meta:
		description = "Detects Atomic Stealer targering MacOS"
		author = "RussianPanda"
		id = "259c5c33-0164-568f-aec4-4fe0a2c6d015"
		date = "2024-01-13"
		modified = "2024-01-17"
		reference = "https://www.bleepingcomputer.com/news/security/macos-info-stealers-quickly-evolve-to-evade-xprotect-detection/"
		source_url = "https://github.com/RussianPanda95/Yara-Rules/blob/790ec6378c8e8262a673603ef0172bedf0967d58/AtomicStealer/Atomic_Stealer.yar#L1-L27"
		license_url = "N/A"
		hash = "dd8aa38c7f06cb1c12a4d2c0927b6107"
		logic_hash = "7601e508aeccba943b54e675212993920c984271f655e68c19efaf6d12cfebd5"
		score = 75
		quality = 58
		tags = "FILE"

	strings:
		$s1 = {8B 09 83 C1 (01|02|04|05|03) 39 C8 0F 85 38 00 00 00 48 8B 85}
		$s2 = {C7 40 04 00 00 00 00 C6 40 08 00 C6 40 09 00}
		$t1 = {80 75 D?}
		$t2 = {0F 57 05 ?? 1B 01 00}
		$t3 = {8A 06 34 DE 88 07 8A 46 01 34 DF 88 47 01}
		$c1 = {28 ?? 40 39}
		$c2 = {64 65 73 6B 77 61 6C 6C 65 74 73}

	condition:
		( uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xcafebabe or uint32( 0 ) == 0xbebafeca ) and all of ( $s* ) and #s1 > 60 and #s2 > 100 or ( all of ( $t* ) and #t1 > 10 and #t2 > 5 ) or ( #c1 > 200 and $c2 )
}
rule DITEKSHEN_MALWARE_Osx_Realtimespy : FILE {
    meta:
		description = "Detects macOS RealtimeSpy monitoring app"
		author = "ditekSHen"
		id = "6485abf3-896c-54cd-ad84-7bd86456e47b"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3141-L3166"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "4ef2e1b8d34962cd3eab23f401b764b38b8332233aa2ae91b218af499d8ab8ff"
		score = 75
		quality = 57
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Trojan.RealtimeSpy"

	strings:
		$x1 = "SPYAGENT4HASHCIPHER" fullword ascii
		$x2 = ":username:password:acctid:compUser:compName:" ascii
		$x3 = ":username:password:acctid:compName:" ascii
		$x4 = "://www.realtime-spy-mac.com/" ascii
		$x5 = "/Users/spytech/" ascii
		$x6 = "shell script \"touch /private/var/db/.AccessibilityAPIEnabled\" password \"pwd\" with administrator privileges" ascii
		$x7 = "Content-Disposition: form-data; name=\"raptor_" ascii
		$c1 = "_OBJC_CLASS_$_LocationLogger" fullword ascii
		$c2 = "_OBJC_CLASS_$_MonitoringFunctions" fullword ascii
		$c3 = "_OBJC_CLASS_$_ProcessLogger" fullword ascii
		$c4 = "_OBJC_CLASS_$_RealtimeLoggingFunctions" fullword ascii
		$c5 = "_OBJC_CLASS_$_Realtime_SpyAppDelegate" fullword ascii
		$c6 = "_OBJC_CLASS_$_ScreenshotLogger" fullword ascii
		$c7 = "_OBJC_CLASS_$_Uploader" fullword ascii
		$c8 = "_OBJC_CLASS_$_UsageLogger" fullword ascii
		$c9 = "_OBJC_CLASS_$_WebsiteLogger" fullword ascii

	condition:
		uint16( 0 ) == 0xfacf and ( 2 of ( $x* ) or 2 of ( $c* ) )
}
rule DITEKSHEN_MALWARE_Osx_Maxofferdeal : FILE {
    meta:
		description = "Detects macOS MaxOfferDeal adware"
		author = "ditekSHen"
		id = "aec4ab77-7025-5856-99fb-aa7b86413c00"
		date = "2020-11-06"
		modified = "2024-11-01"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/malware.yar#L3168-L3187"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "a9788b2049ae7f345760a078b2932e79fe8fc0dd71e0446c213df64480c3e3d6"
		score = 75
		quality = 46
		tags = "FILE"
		clamav_sig = "MALWARE.Osx.Adware.MaxOfferDeal"

	strings:
		$s1 = "clEvE15obfuscated_data" ascii
		$s2 = "%.*s.%.*s" fullword ascii
		$s3 = "_Tt%cSs%zu%.*s%s" fullword ascii
		$s4 = "_Tt%c%zu%.*s%zu%.*s%s" fullword ascii
		$s5 = "__ZL20tFirefoxProfilesPath" ascii
		$s6 = "__ZL22tFirefoxSearchFileName" ascii
		$s7 = "__ZL37tFirefoxDefaultProfileFolderExtension" ascii
		$s8 = "__ZL21tFirefoxPrefsFileName" ascii
		$s9 = "__GLOBAL__sub_I_Firefox.mm" ascii
		$s10 = "add_image_hook_" ascii
		$s11 = "/Library/Caches/com.apple.xbs/Sources/arclite/arclite-66/source/" fullword ascii

	condition:
		uint16( 0 ) == 0xfacf and all of them
}
rule DITEKSHEN_INDICATOR_TOOL_CNC_Earthworm : FILE {
    meta:
		description = "Detects Earthworm C&C Windows/macOS tool"
		author = "ditekSHen"
		id = "4a6edcf3-b3c4-5620-8eac-102b1ce425f8"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L455-L471"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "5045faaaa9e60d4bd506240d51ff78dad4e89ccee0e824e7e5c309a8d3ae2883"
		score = 75
		quality = 50
		tags = "FILE"

	strings:
		$s1 = "lcx_tran 0.0.0.0:%d <--[%4d usec]--> %s:%d" fullword ascii
		$s2 = "ssocksd 0.0.0.0:%d <--[%4d usec]--> socks server" fullword ascii
		$s3 = "rcsocks 0.0.0.0:%d <--[%4d usec]--> 0.0.0.0:%d" fullword ascii
		$s4 = "rssocks %s:%d <--[%4d usec]--> socks server" fullword ascii
		$s5 = "--> %3d <-- (close)used/unused  %d/%d" fullword ascii
		$s6 = "<-- %3d --> (open)used/unused  %d/%d" fullword ascii
		$s7 = "--> %d start server" ascii
		$s8 = "Error on connect %s:%d [proto_init_cmd_rcsocket]" fullword ascii
		$url = "http://rootkiter.com/EarthWrom/" nocase fullword ascii

	condition:
		( uint16( 0 ) == 0xfacf or uint16( 0 ) == 0x5a4d ) and ( 5 of ( $s* ) or $url )
}
rule DITEKSHEN_INDICATOR_TOOL_PWS_Keychaindumper : FILE {
    meta:
		description = "Detects macOS certificate/password keychain dumping tool"
		author = "ditekSHen"
		id = "cec094fa-c651-58a6-a306-f16d8603e536"
		date = "2020-11-06"
		modified = "2024-09-25"
		reference = "https://github.com/ditekshen/detection"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_tools.yar#L473-L484"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "f606bdd5dba2180ffc552c46373b52801a0bd65a538b381fb9f4240efc5bd458"
		score = 75
		quality = 71
		tags = "FILE"
		clamav_sig = "INDICATOR_Osx.Tool.PWS.KeychainDumper"

	strings:
		$s1 = "_getEmptyKeychainItemString" fullword ascii
		$s2 = "NdumpKeychainEntitlements" fullword ascii
		$s3 = "_dumpKeychainEntitlements" fullword ascii

	condition:
		( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf ) and all of them
}
rule DITEKSHEN_INDICATOR_OSX_RMM_Dwagent : FILE {
    meta:
		description = "Detect DWAgent Remote Administration Tool macOS run"
		author = "ditekSHen"
		id = "0eeb9ae3-826e-52b7-bbb8-3f8c4920f5c3"
		date = "2023-08-22"
		modified = "2024-10-04"
		reference = "https://www.cisa.gov/sites/default/files/2023-08/JCDC_RMM_Cyber_Defense_Plan_TLP_CLEAR_508c_1.pdf"
		source_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/yara/indicator_rmm.yar#L565-L580"
		license_url = "https://github.com/ditekshen/detection/blob/e76c93dcdedff04076380ffc60ea54e45b313635/LICENSE.txt"
		logic_hash = "9864668abdd534d8a33940f9513d07356451ce1eaa9233771e82b8138dc0b41b"
		score = 75
		quality = 75
		tags = "FILE"
		clamav1 = "INDICATOR.Osx.RMM.DWAgent-RUN"

	strings:
		$s1 = "net.dwservice.DWAgent" ascii
		$s2 = "-[DWADelegate" ascii
		$s3 = "customWindowsToEnterFullScreenForWindow:onScreen:" ascii

	condition:
		uint16( 0 ) == 0xfeca and all of them
}
rule SEKOIA_Implant_Lin_Geacon : FILE {
    meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "ad71522e-270b-47d0-9c01-081f05a2b72a"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/implant_lin_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		logic_hash = "c6fa5815bf618eb588d511f18231042944dee20c1b13096c44910d43ca552bfa"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint32( 0 ) == 0x464C457F and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Implant_Macos_Geacon : FILE {
    meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "a7784bfa-66a7-47df-b88b-d98217d8cca5"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/implant_macos_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		logic_hash = "284574d185d3777a373f4a19e0870eec5245fb8ea5ebd6124bc281f8c74e0998"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint32( 0 ) == 0xFEEDFACF and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Dropper_Mac_Lazarus_Manuscrypt : FILE {
    meta:
		description = "MacOS Manuscrypt dropped by TraderTraitor"
		author = "Sekoia.io"
		id = "6138bd0c-1fcf-4586-b2b6-29955c7d6266"
		date = "2022-04-19"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/dropper_mac_lazarus_manuscrypt.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		hash = "dced1acbbe11db2b9e7ae44a617f3c12d6613a8188f6a1ece0451e4cd4205156"
		hash = "9d9dda39af17a37d92b429b68f4a8fc0a76e93ff1bd03f06258c51b73eb40efa"
		logic_hash = "dbe75a34f91906fc275c04af0fc068923993bab37a7574b3fe38733d87f31835"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "networksetup -getwebproxy '%s'" ascii
		$ = "Cookie: _ga=%s%02d%d%d%02d%s" ascii
		$ = "networksetup -listallnetworkservices" ascii
		$ = "gid=%s%02d%d%03d%s" ascii

	condition:
		uint32( 0 ) == 0xFEEDFACF and all of them
}
rule SEKOIA_Apt37_Rokrat_Macho {
    meta:
		description = "Detects Public key of Macho samples of RokRAT"
		author = "Sekoia.io"
		id = "c54fb9ae-85fa-4c36-bab9-6c6d989262ba"
		date = "2022-09-29"
		modified = "2024-12-19"
		reference = "https://github.com/SEKOIA-IO/Community"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/apt37_rokrat_macho.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		logic_hash = "526dc4594db099ed8090a673e761f84f6dd7ce860e380214e4d3f1ec08fc2345"
		score = 75
		quality = 66
		tags = ""
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$s1 = { 4D 49 49 42 49 6A 41 4E 42 67 6B 71 68 6B 69 47 39 77 30 42 41 51 45 46 41 41 4F 43 41 51 38 41 4D 49 49 42 43 67 4B 43 41 51 45 41 73 47 52 59 53 45 56 76 77 6D 66 42 46 4E 42 6A 4F 7A 2B 51}
		$s2 = {70 61 78 35 72 7A 57 66 2F 4C 54 2F 79 46 55 51 41 31 7A 72 41 31 6E 6A 6A 79 49 48 72 7A 70 68 67 63 39 74 67 47 48 73 2F 37 74 73 57 70 38 65 35 64 4C 6B 41 59 73 56 47 68 57 41 50 73 6A 79}
		$s3 = {31 67 78 30 64 72 62 64 4D 6A 6C 54 62 42 59 54 79 45 67 35 50 67 79 2F 35 4D 73 45 4E 44 64 6E 73 43 52 57 72 32 33 5A 61 4F 45 4C 76 48 48 56 56 38 43 4D 43 38 46 75 34 57 62 61 7A 38 30 4C}
		$s4 = {47 68 67 38 69 73 56 50 45 48 43 38 48 2F 79 47 74 6A 48 50 59 46 56 65 36 6C 77 56 72 2F 4D 58 6F 4B 63 70 78 31 33 53 31 4B 38 6E 6D 44 51 4E 41 68 4D 70 54 31 61 4C 61 47 2F 36 51 69 6A 68}
		$s5 = {57 34 50 2F 52 46 51 71 2B 46 64 69 61 33 66 46 65 68 50 67 35 44 74 59 44 39 30 72 53 33 73 64 46 4B 6D 6A 39 4E 36 4D 4F 30 2F 57 41 56 64 5A 7A 47 75 45 58 44 35 33 4C 48 7A 39 65 5A 77 52}
		$s6 = {39 59 38 37 38 36 6E 56 44 72 6C 6D 61 35 59 43 4B 70 71 55 5A 35 63 34 36 77 57 33 67 59 57 69 33 73 59 2B 56 53 33 62 32 46 64 41 4B 43 4A 68 54 66 43 79 38 32 41 55 47 71 50 53 56 66 4C 61}
		$s7 = {6D 51 49 44 41 51 41 42}

	condition:
		all of them
}
rule SEKOIA_Implant_Win_Geacon : FILE {
    meta:
		description = "Finds Geacon samples based on specific strings"
		author = "Sekoia.io"
		id = "064eabe0-aee5-4e5e-9f5e-69b32b1ba0da"
		date = "2024-01-11"
		modified = "2024-12-19"
		reference = "https://www.sentinelone.com/blog/geacon-brings-cobalt-strike-capabilities-to-macos-threat-actors/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/implant_win_geacon.yar#L1-L35"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		logic_hash = "74b0d2fbb8b7f6666543ba4fdfd9f9d2064d3a89d21c90d794b57f0009199fea"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$gea01 = "geacon/config.init" ascii
		$gea02 = "geacon_pro-master/config/config.go" ascii
		$gea03 = "geacon_plus-main/config/config.go" ascii
		$gea04 = "command type %d is not support by geacon now" ascii
		$gea05 = "main/sysinfo.GeaconID" ascii
		$str01 = "command.StealToken" ascii
		$str02 = "command.MakeToken" ascii
		$str03 = "command/misc.go" ascii
		$str04 = "config/c2profile.go" ascii
		$str05 = "crypt.AesCBCDecrypt" ascii
		$str06 = "packet.File_Browse" ascii
		$str07 = "packet.FirstBlood" ascii
		$str08 = "packet.ParseCommandShell" ascii
		$str09 = "packet.ParseCommandUpload" ascii
		$str10 = "packet.PushResult" ascii
		$str11 = "sysinfo.GetComputerName" ascii
		$str12 = "sysinfo.IsOSX64" ascii
		$str13 = "util..inittask" ascii

	condition:
		uint16( 0 ) == 0x5A4D and ( ( 1 of ( $gea* ) and 2 of ( $str* ) ) or 8 of ( $str* ) )
}
rule SEKOIA_Downloader_Mac_Rustbucket : FILE {
    meta:
		description = "RustBucket fake PDF reader"
		author = "Sekoia.io"
		id = "5a003b68-ad9a-47f9-b157-dd898181dac2"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://www.jamf.com/blog/bluenoroff-apt-targets-macos-rustbucket-malware/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/downloader_mac_rustbucket.yar#L1-L31"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		hash = "38106b043ede31a66596299f17254d3f23cbe1f983674bf9ead5006e0f0bf880"
		hash = "bea33fb3205319868784c028418411ee796d6ee3dfe9309f143e7e8106116a49"
		hash = "7981ebf35b5eff8be2f3849c8f3085b9cec10d9759ff4d3afd46990520de0407"
		hash = "e74e8cdf887ae2de25590c55cb52dad66f0135ad4a1df224155f772554ea970c"
		logic_hash = "1b9e9a3f4fb4804eb94ab8d3573781d67f96d180b258cfc10be384eec44509ed"
		score = 75
		quality = 78
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$down_exec1 = "_down_update_run" nocase
		$down_exec2 = "downAndExec" nocase
		$encrypt1 = "_encrypt_pdf"
		$encrypt2 = "_encrypt_data"
		$error_msg1 = "_alertErr"
		$error_msg2 = "_show_error_msg"
		$view_pdf1 = "-[PEPWindow view_pdf:]"
		$view_pdf2 = "-[PEPWindow viewPDF:]"
		$macho_magic = {CF FA ED FE}
		$java_magic = {CA FE BA BE}

	condition:
		($macho_magic at 0 or $java_magic at 0 ) and 5 of them and filesize > 50KB
}
rule SEKOIA_Implant_Mac_Rustbucket : FILE {
    meta:
		description = "Detect the RustBucket malware"
		author = "Sekoia.io"
		id = "fcbb745d-7f56-4c51-9db5-427da22a0c68"
		date = "2023-04-24"
		modified = "2024-12-19"
		reference = "https://www.jamf.com/blog/bluenoroff-apt-targets-macos-rustbucket-malware/"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/implant_mac_rustbucket.yar#L1-L21"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		hash = "9ca914b1cfa8c0ba021b9e00bda71f36cad132f27cf16bda6d937badee66c747"
		logic_hash = "ab7bc706b0d3f0dcd739ffe7f8153ba7377892143d8d53ce1591519ffe4ae84f"
		score = 75
		quality = 80
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$ = "/Users/hero/"
		$ = "PATHIpv6Ipv4Bodyslotpath"
		$macho_magic = {CF FA ED FE}
		$java_magic = {CA FE BA BE}

	condition:
		($macho_magic at 0 or $java_magic at 0 ) and all of them
}
rule SEKOIA_Infostealer_Mac_Realst : FILE {
    meta:
		description = "Finds Realst Stealer samples based on specific strings"
		author = "Sekoia.io"
		id = "16a89317-c92d-4e13-94d3-a85a915f52e5"
		date = "2023-09-11"
		modified = "2024-12-19"
		reference = "https://iamdeadlyz.gitbook.io/malware-research/july-2023/fake-blockchain-games-deliver-redline-stealer-and-realst-stealer-a-new-macos-infostealer-malware#realst-stealer-macos"
		source_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/yara_rules/infostealer_mac_realst.yar#L1-L32"
		license_url = "https://github.com/SEKOIA-IO/Community/blob/0cfec8bbe51bc92b4d612e53312f158b7597b151/LICENSE.md"
		logic_hash = "72e694e5c32cbaeb7dff7913fde671619e2c8d892e552546dd1682e38f6804c5"
		score = 75
		quality = 30
		tags = "FILE"
		version = "1.0"
		classification = "TLP:CLEAR"

	strings:
		$str00 = "realst@" ascii
		$str01 = "IP:" ascii
		$str02 = "OS:" ascii
		$str03 = "PC PASSWORD:" ascii
		$str04 = "Cookies:" ascii
		$str05 = "Wallets:" ascii
		$str06 = "Apps:" ascii
		$str07 = "USERNAME: ]" ascii
		$str08 = "FILENAME:" ascii
		$str09 = "multipart/form-data; boundary=" ascii
		$str10 = "src/browsers/firefox/modules/decryptors.rs" ascii
		$str11 = "{\"event_id\":\"" ascii
		$str12 = "..browsers..firefox..modules..data_stealers.." ascii
		$str13 = "..browsers..chromium..modules..key_stealers.." ascii
		$str14 = "..browsers..firefox..modules..decryptors.." ascii
		$str15 = "url: , login: , password:" ascii

	condition:
		( uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xcafebabe or uint32( 0 ) == 0xbebafeca ) and 13 of ( $str* )
}
rule SIGNATURE_BASE_APT_MAL_Macos_NK_3CX_Malicious_Samples_Mar23_1 : FILE {
    meta:
		description = "Detects malicious macOS application related to 3CX compromise (decrypted payload)"
		author = "Florian Roth (Nextron Systems)"
		id = "ff39e577-7063-5025-bead-68394a86c87c"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.reddit.com/r/crowdstrike/comments/125r3uu/20230329_situational_awareness_crowdstrike/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_mal_3cx_compromise_mar23.yar#L168-L184"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "b86c695822013483fa4e2dfdf712c5ee777d7b99cbad8c2fa2274b133481eadb"
		hash = "ac99602999bf9823f221372378f95baa4fc68929bac3a10e8d9a107ec8074eca"
		hash = "51079c7e549cbad25429ff98b6d6ca02dc9234e466dd9b75a5e05b9d7b95af72"
		logic_hash = "c2733c2f7dcca82e5a0b2301777fb54853d04dfa893bcf88ecbec34d37e1a38a"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "20230313064152Z0"
		$s2 = "Developer ID Application: 3CX (33CF4654HL)"

	condition:
		( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and all of them
}
rule SIGNATURE_BASE_APT_MAL_Macos_NK_3CX_DYLIB_Mar23_1 {
    meta:
		description = "Detects malicious DYLIB files related to 3CX compromise"
		author = "Florian Roth (Nextron Systems)"
		id = "a19904d3-9b2d-561f-b734-20bf09584fa7"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.sentinelone.com/blog/smoothoperator-ongoing-campaign-trojanizes-3cx-software-in-software-supply-chain-attack/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_mal_3cx_compromise_mar23.yar#L188-L214"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "a64fa9f1c76457ecc58402142a8728ce34ccba378c17318b3340083eeb7acc67"
		hash = "fee4f9dabc094df24d83ec1a8c4e4ff573e5d9973caa676f58086c99561382d7"
		logic_hash = "e52c76de1e995cc7084ddb390b60f4bc66e5bdf89aaa28ef3fd70578ed3145a6"
		score = 80
		quality = 85
		tags = ""

	strings:
		$xc1 = { 37 15 00 13 16 16 1B 55 4F 54 4A 5A 52 2D 13 14 
               1E 15 0D 09 5A 34 2E 5A 4B 4A 54 4A 41 5A 2D 13
               14 4C 4E 41 5A 02 4C 4E 53 5A 3B 0A 0A 16 1F 2D
               1F 18 31 13 0E 55 4F 49 4D 54 49 4C 5A 52 31 32
               2E 37 36 56 5A 16 13 11 1F 5A 3D 1F 19 11 15 53
               5A 39 12 08 15 17 1F 55 4B 4A 42 54 4A 54 4F 49
               4F 43 54 4B 48 42 5A 29 1B 1C 1B 08 13 55 4F 49
               4D 54 49 4C 7A }
		$xc2 = { 41 49 19 02 25 1b 0f 0e 12 25 0e 15 11 1f 14 25 19 15 14 0e 1f 14 0e 47 5f 09 41 25 25 0e 0f 0e 17 1b 47 }
		$xc3 = { 55 29 03 09 0e 1f 17 55 36 13 18 08 1b 08 03 55 39 15 08 1f 29 1f 08 0c 13 19 1f 09 55 29 03 09 0e 1f 17 2c 1f 08 09 13 15 14 54 0a 16 13 09 0e }

	condition:
		1 of them
}
rule SIGNATURE_BASE_MAL_3Cxdesktopapp_Macos_Backdoor_Mar23 : FILE {
    meta:
		description = "Detects 3CXDesktopApp MacOS Backdoor component"
		author = "X__Junior (Nextron Systems)"
		id = "80046c8e-0c2a-5885-b140-a6084f48160d"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://www.volexity.com/blog/2023/03/30/3cx-supply-chain-compromise-leads-to-iconic-incident/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_mal_3cx_compromise_mar23.yar#L251-L275"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "a64fa9f1c76457ecc58402142a8728ce34ccba378c17318b3340083eeb7acc67"
		logic_hash = "777a0a29c376f3697021dd627e716c31bda7933c5f40a8fe79b80e3cea46ce43"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$sa1 = "%s/.main_storage" ascii fullword
		$sa2 = "%s/UpdateAgent" ascii fullword
		$op1 = { 31 C0 41 80 34 06 ?? 48 FF C0 48 83 F8 ?? 75 ?? BE ?? ?? ?? ?? BA ?? ?? ?? ?? 4C 89 F7 48 89 D9 E8 ?? ?? ?? ?? 48 89 DF E8 ?? ?? ?? ?? 48 89 DF E8 ?? ?? ?? ?? 4C 89 F7 5B 41 5E 41 5F E9 ?? ?? ?? ?? 5B 41 5E 41 5F C3}
		$op2 = { 0F 11 84 24 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 0F 29 84 24 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 0F 29 84 24 ?? ?? ?? ?? 31 C0 80 B4 04 ?? ?? ?? ?? ?? 48 FF C0}

	condition:
		(( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and filesize < 6MB and ( ( 1 of ( $sa* ) and 1 of ( $op* ) ) or all of ( $sa* ) ) ) or ( all of ( $op* ) )
}
rule SIGNATURE_BASE_APT_MAL_NK_3CX_Macos_Elextron_App_Mar23_1 : FILE {
    meta:
		description = "Detects macOS malware used in the 3CX incident"
		author = "Florian Roth (Nextron Systems)"
		id = "7a3755d4-37e5-5d3b-93aa-34edb557f2d5"
		date = "2023-03-31"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_mal_3cx_compromise_mar23.yar#L306-L328"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "51079c7e549cbad25429ff98b6d6ca02dc9234e466dd9b75a5e05b9d7b95af72"
		hash = "f7ba7f9bf608128894196cf7314f68b78d2a6df10718c8e0cd64dbe3b86bc730"
		logic_hash = "00dd28c3edd94e04e35ee9e3a43c30b5a0a1ad21ec8ecf2099bbeb9de2fca8d0"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "com.apple.security.cs.allow-unsigned-executable-memory" ascii
		$a2 = "com.electron.3cx-desktop-app" ascii fullword
		$s1 = "s8T/RXMlALbXfowom9qk15FgtdI=" ascii
		$s2 = "o8NQKPJE6voVZUIGtXihq7lp0cY=" ascii

	condition:
		uint16( 0 ) == 0xfacf and filesize < 400KB and ( all of ( $a* ) and 1 of ( $s* ) )
}
rule SIGNATURE_BASE_MAL_3Cxdesktopapp_Macos_Updateagent_Mar23 : FILE {
    meta:
		description = "Detects 3CXDesktopApp MacOS UpdateAgent backdoor component"
		author = "Florian Roth (Nextron Systems)"
		id = "596eb6d0-f96f-5106-ae67-9372d238e4cf"
		date = "2023-03-30"
		modified = "2023-12-05"
		reference = "https://twitter.com/patrickwardle/status/1641692164303515653?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_mal_3cx_compromise_mar23.yar#L330-L354"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "9e9a5f8d86356796162cee881c843cde9eaedfb3"
		logic_hash = "0818a8f0b59a9baaefaa0b505f8261e0e0df283e79da8e95dc71e9afdca224ab"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$a1 = "/3CX Desktop App/.main_storage" ascii
		$x1 = ";3cx_auth_token_content=%s;__tutma=true"
		$s1 = "\"url\": \"https://"
		$s3 = "/dev/null"
		$s4 = "\"AccountName\": \""

	condition:
		uint16( 0 ) == 0xfeca and filesize < 6MB and ( 1 of ( $x* ) or ( $a1 and all of ( $s* ) ) ) or all of them
}
rule SIGNATURE_BASE_SUSP_Macos_Plist_Suspicious : FILE {
    meta:
		description = "Suspicious PLIST files in MacOS (possible malware persistence)"
		author = "John Lambert @JohnLaTwC"
		id = "61b5986d-35c9-5e1a-a077-14cecdbed36f"
		date = "2018-12-14"
		modified = "2025-06-03"
		old_rule_name = "gen_malware_MacOS_plist_suspicious"
		reference = "https://objective-see.com/blog/blog_0x3A.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_malware_MacOS_plist_suspicious.yar#L1-L73"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "0541fc6a11f4226d52ae3d4158deb8f50ed61b25bb5f889d446102e1ee57b76d"
		hash = "6cc6abec7d203f99c43ce16630edc39451428d280b02739757f17fd01fc7dca3"
		hash = "76eb97aba93979be06dbf0a872518f9514d0bb20b680c887d6fd5cc79dce3681"
		hash = "8921e3f1955f7141d1231f8cfd95230143525f259e578fdc1dd98494f62ec4a1"
		hash = "9a3fd0d2b0bca7d2f7e3c70cb15a7005a1afa1ce78371fd3fa9c526a288b64ce"
		hash = "737355121685afc38854413d8a1657886f9aa24f54673953749386defe843017"
		hash = "9b77622653934995ee8bb5562df311f5bb6d6719933e2671fe231a664da76d30"
		hash = "c449f8115b4b939271cb92008a497457e1ab1cf2cbd8f4b58f7ba955cf5624f0"
		hash = "cdb2fb9c8e84f0140824403ec32a2431fb357cd0f184c1790152834cc3ad3c1b"
		logic_hash = "52076ec107b5bcbbe35265dfc4034a6a25a453459d22392848980b22115f68bc"
		score = 60
		quality = 83
		tags = "FILE"

	strings:
		$sr1 = "PropertyList-"
		$sr2 = "<plist"
		$p1 = "python" ascii
		$p2 = "<string>-c" ascii
		$v0 = /\<string\>[\/|\w]{0,20}\+[\/|\+|=|\w]{59,80}\<\/string\>/
		$v1 = "curl " fullword
		$v2 = "PAYLOAD_DATA"
		$v3 = "base64"
		$vb640 = /(AAQQBZAEwATwBBAEQAXwBCAEEAUwBFADYANA|AEEAWQBMAE8AQQBEAF8AQgBBAFMARQA2ADQA|BBWUxPQURfQkFTRTY0|QVlMT0FEX0JBU0U2N|UABBAFkATABPAEEARABfAEIAQQBTAEUANgA0A|UEFZTE9BRF9CQVNFNj)/
		$vb641 = /(AHUAYgBwAHIAbwBjAGUAcwBzA|c3VicHJvY2Vzc|cwB1AGIAcAByAG8AYwBlAHMAcw|dWJwcm9jZXNz|MAdQBiAHAAcgBvAGMAZQBzAHMA|N1YnByb2Nlc3)/
		$vb642 = "IyEvdXNy"
		$vb643 = "IyAtKi0"
		$vb644 = /(AGQAZABfAGgAZQBhAGQAZQByA|EAZABkAF8AaABlAGEAZABlAHIA|FkZF9oZWFkZX|YQBkAGQAXwBoAGUAYQBkAGUAcg|YWRkX2hlYWRlc|ZGRfaGVhZGVy)/
		$fp1 = "&#10;do&#10;&#09;echo"
		$fp2 = "<string>com.cisco.base64</string>"
		$fp3 = "video/mp4;base64"
		$fp4 = "<key>Content-Length</key>"
		$fp5 = "<string>yara</string>"
		$fp6 = "<key>Frameworks/base64.framework</key>" ascii
		$fp7 = "<key>Headers/base64.h</key>" ascii
		$fp8 = "database64" ascii fullword
		$fp9 = "<!-- last arg will be replaced by the installer script -->" ascii
		$fp10 = "<key>/usr/local/bin/python</key>"
		$fp11 = "<key>/usr/bin/ruby</key>"
		$fp12 = "installer script"
		$fp13 = "backupgridsoftware."
		$fp14 = "<string>3d45fa493e6db1537783a6ad37e464a9</string>"
		$fp15 = "<string>1815ecf78ce641b94f44d751588ed3ed</string>"
		$fp16 = "<string>3df5ea4616954ada685d14179e43c4aa</string>"
		$fp17 = "<string>1PasswordSafariAppExtension</string>"

	condition:
		filesize < 20KB and uint32be( 0 ) == 0x3c3f786d and all of ( $sr* ) and @sr2 [ 1 ] < 0x100 and ( 1 of ( $v* ) or all of ( $p* ) ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_Persistence_Agent_Macos : FILE {
    meta:
		description = "Detects a Python agent that establishes persistence on macOS"
		author = "John Lambert @JohnLaTwC"
		id = "9c69af3c-ee85-58ac-8b78-66760addc117"
		date = "2018-02-24"
		modified = "2023-12-05"
		reference = "https://ghostbin.com/paste/mz5nf"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_osx_pyagent_persistence.yar#L1-L40"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "4288a81779a492b5b02bad6e90b2fa6212fa5f8ee87cc5ec9286ab523fc02446 cec7be2126d388707907b4f9d681121fd1e3ca9f828c029b02340ab1331a5524 e1cf136be50c4486ae8f5e408af80b90229f3027511b4beed69495a042af95be"
		logic_hash = "2613fcb32cbdbb24df6c48fcb5d16549783e50246d2cdb8c473375644dd88254"
		score = 75
		quality = 83
		tags = "FILE"

	strings:
		$h1 = "#!/usr/bin/env python"
		$s_1 = "<plist" ascii fullword
		$s_2 = "ProgramArguments" ascii fullword
		$s_3 = "Library" ascii fullword
		$sinterval_1 = "StartInterval" ascii fullword
		$sinterval_2 = "RunAtLoad" ascii fullword
		$e_1 = /(AHAAbABpAHMAdA|cGxpc3|PABwAGwAaQBzAHQA|PHBsaXN0|wAcABsAGkAcwB0A|xwbGlzd)/ ascii
		$e_2 = /(AAcgBvAGcAcgBhAG0AQQByAGcAdQBtAGUAbgB0AHMA|AHIAbwBnAHIAYQBtAEEAcgBnAHUAbQBlAG4AdABzA|Byb2dyYW1Bcmd1bWVudH|cm9ncmFtQXJndW1lbnRz|UAByAG8AZwByAGEAbQBBAHIAZwB1AG0AZQBuAHQAcw|UHJvZ3JhbUFyZ3VtZW50c)/ ascii
		$e_4 = /(AGkAYgByAGEAcgB5A|aWJyYXJ5|TABpAGIAcgBhAHIAeQ|TGlicmFye|wAaQBiAHIAYQByAHkA|xpYnJhcn)/ ascii
		$einterval_a = /(AHQAYQByAHQASQBuAHQAZQByAHYAYQBsA|dGFydEludGVydmFs|MAdABhAHIAdABJAG4AdABlAHIAdgBhAGwA|N0YXJ0SW50ZXJ2YW|U3RhcnRJbnRlcnZhb|UwB0AGEAcgB0AEkAbgB0AGUAcgB2AGEAbA)/ ascii
		$einterval_b = /(AHUAbgBBAHQATABvAGEAZA|dW5BdExvYW|IAdQBuAEEAdABMAG8AYQBkA|J1bkF0TG9hZ|UgB1AG4AQQB0AEwAbwBhAGQA|UnVuQXRMb2Fk)/ ascii

	condition:
		uint32( 0 ) == 0x752f2123 and $h1 at 0 and filesize < 120KB and ( ( all of ( $s_* ) and 1 of ( $sinterval* ) ) or ( all of ( $e_* ) and 1 of ( $einterval* ) ) )
}
rule SIGNATURE_BASE_OSX_Backdoor_Bella : FILE {
    meta:
		description = "Bella MacOS/OSX backdoor"
		author = "John Lambert @JohnLaTwC"
		id = "d2a994f9-acff-5de4-8f70-453b5d4d7947"
		date = "2018-02-23"
		modified = "2023-12-05"
		reference = "https://twitter.com/JohnLaTwC/status/911998777182924801"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_osx_backdoor_bella.yar#L2-L42"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "4288a81779a492b5b02bad6e90b2fa6212fa5f8ee87cc5ec9286ab523fc02446 cec7be2126d388707907b4f9d681121fd1e3ca9f828c029b02340ab1331a5524 e1cf136be50c4486ae8f5e408af80b90229f3027511b4beed69495a042af95be"
		logic_hash = "c2fa72072decd850698fbaaa9c2a6687cdf64e6bac068ff52a97963053db4339"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$h1 = "#!/usr/bin/env"
		$s0 = "subprocess" fullword ascii
		$s1 = "import sys" fullword ascii
		$s2 = "shutil" fullword ascii
		$p0 = "create_bella_helpers" fullword ascii
		$p1 = "is_there_SUID_shell" fullword ascii
		$p2 = "BELLA IS NOW RUNNING" fullword ascii
		$p3 = "SELECT * FROM bella WHERE id" fullword ascii
		$subpart1_a = "inject_payloads" fullword ascii
		$subpart1_b = "check_if_payloads" fullword ascii
		$subpart1_c = "updateDB" fullword ascii
		$subpart2_a = "appleIDPhishHelp" fullword ascii
		$subpart2_b = "appleIDPhish" fullword ascii
		$subpart2_c = "iTunes" fullword ascii

	condition:
		uint32( 0 ) == 0x752f2123 and $h1 at 0 and filesize < 120KB and @s0 [ 1 ] < 100 and @s1 [ 1 ] < 100 and @s2 [ 1 ] < 100 and 1 of ( $p* ) or all of ( $subpart1_* ) or all of ( $subpart2_* )
}
rule SIGNATURE_BASE_EXPL_HKTL_Macos_Switcharoo_CVE_2022_46689_Dec22 : CVE_2022_46689 FILE {
    meta:
		description = "Detects POCs that exploit privilege escalation vulnerability CVE-2022-46689 on macOS"
		author = "Florian Roth (Nextron Systems)"
		id = "25c551f7-48ae-5e71-b86e-68fb440262e5"
		date = "2022-12-19"
		modified = "2023-12-05"
		reference = "Internal Research"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/expl_macos_switcharoo_dec22.yar#L2-L40"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "64acd79a37b6f8443250dd33e95bd933ee39fc6d4f35ba6a987dae878d017386"
		hash = "6c2ace75000de8a7e8786f28b1b41eed72816991a0961475c6800753bfe9278c"
		hash = "6ce080b236ea3aa3b4c992d12af99445ab800abc709c6abbef852a9f0cf219b6"
		hash = "83cc4d72686aedf5218f07e60e759b4849b368975b70352dbba6fac4e8cde72b"
		hash = "a7b7fcfd609ff653d32c133417c0d3ffd9f581fb6de05ddbdead4d36cb6e3cc2"
		hash = "b2a97edb0ddc30ecc1a0b0c0739820bbef787394b44ab997393475de2ebf7b60"
		hash = "c7a64c6da5cf5046ae5c683d0264a32027110a2736b4c1b0df294e29a061a865"
		hash = "d517cde0d45e6930336538c89b310d5d540a66c921bf6f6f9b952e721b2f6a11"
		hash = "d53a559ea9131fe42eacf51431da3adde5a8fd5c2f3198f0d5451ef62ed33888"
		logic_hash = "c2cbe12a01a38db522c49143c5168d3519ef974b4e6157cb251aa66707c69d78"
		score = 80
		quality = 85
		tags = "CVE-2022-46689, FILE"

	strings:
		$x1 = "vm_read_overwrite: KERN_SUCCESS:%d KERN_PROTECTION_FAILURE:%d other:%d" ascii fullword
		$x2 = "Execting: %s (posix_spawn returned: %d)" ascii fullword
		$x3 = "/usr/bin/sed -e \"s/rootok/permit/g\" /etc" ascii fullword
		$x4 = "vm_unaligned_copy_switch_race" ascii fullword
		$s1 = "RO mapping was modified" ascii fullword
		$s2 = "Ran %d times in %ld seconds with no failure" ascii fullword
		$opa1 = { 4c 89 ee 31 c9 41 b8 00 40 00 00 6a 01 41 5c 41 54 6a 03 58 }
		$opa2 = { e8 ?? 01 00 00 48 8b 05 ?? 0? 00 00 8b 38 48 8b 13 44 8b 4b 14 48 83 ec 08 4c 89 ee 31 c9 }
		$opa3 = { 48 89 45 c8 48 8d 43 08 48 89 45 d0 4c 8b 7d c8 4c 8b 6d d0 6a 64 41 5e 80 7b 60 00 }
		$opb1 = { 55 48 89 e5 48 83 ec 60 48 8b 05 ?1 06 00 00 48 8b 00 48 89 45 f8 0f 28 05 ?b 07 00 00 48 8d 75 d0 }

	condition:
		( filesize < 400KB and 1 of ( $x* ) ) or ( ( uint16( 0 ) == 0xfacf or ( uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) ) and filesize < 400KB and 2 of them )
}
rule SIGNATURE_BASE_EXPL_Macos_Switcharoo_Indicator_Dec22 : CVE_2022_46689 FILE {
    meta:
		description = "Detects indicators found after exploitations of CVE-2022-46689"
		author = "Florian Roth (Nextron Systems)"
		id = "d5d9559a-c19c-5ddc-9d72-701986a9d7ac"
		date = "2022-12-19"
		modified = "2023-12-05"
		reference = "https://github.com/zhuowei/MacDirtyCowDemo"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/expl_macos_switcharoo_dec22.yar#L42-L54"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "9b9ea134fc4b3a7b15ae585ced2e12cbe1defc54bc6175282d6b7a2a0b65abd1"
		score = 65
		quality = 85
		tags = "CVE-2022-46689, FILE"

	strings:
		$x1 = "auth       sufficient     pam_permit.so" ascii

	condition:
		filesize < 1KB and $x1
}
rule SIGNATURE_BASE_MAL_RANSOM_LNX_Macos_Lockbit_Apr23_1 : FILE {
    meta:
		description = "Detects LockBit ransomware samples for Linux and macOS"
		author = "Florian Roth"
		id = "c01cb907-7d30-5487-b908-51f69ddb914c"
		date = "2023-04-15"
		modified = "2023-12-05"
		reference = "https://twitter.com/malwrhunterteam/status/1647384505550876675?s=20"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/mal_lockbit_lnx_macos_apr23.yar#L2-L41"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "0a2bffa0a30ec609d80591eef1d0994d8b37ab1f6a6bad7260d9d435067fb48e"
		hash = "9ebcbaf3c9e2bbce6b2331238ab584f95f7ced326ca4aba2ddcc8aa8ee964f66"
		hash = "a405d034c01a357a89c9988ffe8a46a165915df18fd297469b2bcaaf97578442"
		hash = "c9cac06c9093e9026c169adc3650b018d29c8b209e3ec511bbe34cbe1638a0d8"
		hash = "dc3d08480f5e18062a0643f9c4319e5c3f55a2e7e93cd8eddd5e0c02634df7cf"
		hash = "e77124c2e9b691dbe41d83672d3636411aaebc0aff9a300111a90017420ff096"
		hash = "0be6f1e927f973df35dad6fc661048236d46879ad59f824233d757ec6e722bde"
		hash = "3e4bbd21756ae30c24ff7d6942656be024139f8180b7bddd4e5c62a9dfbd8c79"
		logic_hash = "6d838e8b207b97d7c335dc4066de2c6dc87f7adc9cac31742677edbe85386cf7"
		score = 85
		quality = 85
		tags = "FILE"

	strings:
		$x1 = "restore-my-files.txt" ascii fullword
		$s1 = "ntuser.dat.log" ascii fullword
		$s2 = "bootsect.bak" ascii fullword
		$s3 = "autorun.inf" ascii fullword
		$s4 = "lockbit" ascii fullword
		$xc1 = { 33 38 36 00 63 6D 64 00 61 6E 69 00 61 64 76 00 6D 73 69 00 6D 73 70 00 63 6F 6D 00 6E 6C 73 }
		$xc2 = { 6E 74 6C 64 72 00 6E 74 75 73 65 72 2E 64 61 74 2E 6C 6F 67 00 62 6F 6F 74 73 65 63 74 2E 62 61 6B }
		$xc3 = { 76 6D 2E 73 74 61 74 73 2E 76 6D 2E 76 5F 66 72 65 65 5F 63 6F 75 6E 74 00 61 2B 00 2F 2A }
		$op1 = { 84 e5 f0 00 f0 e7 10 40 2d e9 2e 10 a0 e3 00 40 a0 e1 ?? fe ff }
		$op2 = { 00 90 a0 e3 40 20 58 e2 3f 80 08 e2 3f 30 c2 e3 09 20 98 e1 08 20 9d }
		$op3 = { 2d e9 01 70 43 e2 07 00 13 e1 01 60 a0 e1 08 d0 4d e2 02 40 }

	condition:
		( uint32be( 0 ) == 0x7f454c46 or uint16( 0 ) == 0xfeca or uint16( 0 ) == 0xfacf or uint32( 0 ) == 0xbebafeca ) and ( 1 of ( $x* ) or 3 of them ) or 2 of ( $x* ) or 5 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Apr23_1 {
    meta:
		description = "Detects indicators found in LockBit ransomware"
		author = "Florian Roth"
		id = "75dc8b95-16f0-5170-a7d6-fc10bb778348"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/mal_lockbit_lnx_macos_apr23.yar#L43-L67"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "cd5bffa5571abfd1446b065d26c8c23f00fe1376d505af539c6f37356014a86f"
		score = 75
		quality = 85
		tags = ""

	strings:
		$xe1 = "-i '/path/to/crypt'" xor
		$xe2 = "http://lockbit" xor
		$s1 = "idelayinmin" ascii
		$s2 = "bVMDKmode" ascii
		$s3 = "bSelfRemove" ascii
		$s4 = "iSpotMaximum" ascii
		$fp1 = "<html"

	condition:
		(1 of ( $x* ) or 4 of them ) and not 1 of ( $fp* )
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Locker_LOG_Apr23_1 {
    meta:
		description = "Detects indicators found in LockBit ransomware log files"
		author = "Florian Roth"
		id = "aa0a2393-e5a2-5151-8afb-91a9bb922179"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/mal_lockbit_lnx_macos_apr23.yar#L69-L84"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "d5f96e601150209382d3f6458863bc79768beb99b587aa8d9ba37cb2c11ef634"
		score = 75
		quality = 85
		tags = ""

	strings:
		$s1 = " is encrypted. Checksum after encryption "
		$s2 = "~~~~~Hardware~~~~"
		$s3 = "[+] Add directory to encrypt:"
		$s4 = "][+] Launch parameters: "

	condition:
		2 of them
}
rule SIGNATURE_BASE_MAL_RANSOM_Lockbit_Forensicartifacts_Apr23_1 {
    meta:
		description = "Detects forensic artifacts found in LockBit intrusions"
		author = "Florian Roth"
		id = "e716030c-ee78-51dc-919c-cf59e93da976"
		date = "2023-04-17"
		modified = "2023-12-05"
		reference = "https://objective-see.org/blog/blog_0x75.html"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/mal_lockbit_lnx_macos_apr23.yar#L86-L101"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "81021f8c9aed17c007d7329a598c644a706fa9750818c8974984eefcba8d06c2"
		score = 75
		quality = 85
		tags = ""

	strings:
		$x1 = "/tmp/locker.log" ascii fullword
		$x2 = "Executable=LockBit/locker_" ascii
		$xc1 = { 54 6F 72 20 42 72 6F 77 73 65 72 20 4C 69 6E 6B 73 3A 0D 0A 68 74 74 70 3A 2F 2F 6C 6F 63 6B 62 69 74 }

	condition:
		1 of ( $x* )
}
rule SIGNATURE_BASE_OSX_Backdoor_Evilosx : FILE {
    meta:
		description = "EvilOSX MacOS/OSX backdoor"
		author = "John Lambert @JohnLaTwC"
		id = "6940e355-53d2-51e3-afd0-13303a311e9a"
		date = "2018-02-23"
		modified = "2023-12-05"
		reference = "https://github.com/Marten4n6/EvilOSX, https://twitter.com/JohnLaTwC/status/966139336436498432"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_osx_evilosx.yar#L1-L34"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		hash = "89e5b8208daf85f549d9b7df8e2a062e47f15a5b08462a4224f73c0a6223972a"
		logic_hash = "393abf7cf74f8d079049cf8f0bdb3a79bf16185c80c43b823e19b67a9031aef6"
		score = 75
		quality = 85
		tags = "FILE"

	strings:
		$h1 = "#!/usr/bin/env"
		$s0 = "import base64" fullword ascii
		$s1 = "b64decode" fullword ascii
		$x0 = "EvilOSX" fullword ascii
		$x1 = "get_launch_agent_directory" fullword ascii
		$enc_x0 = /(AHYAaQBsAE8AUwBYA|dmlsT1NY|RQB2AGkAbABPAFMAWA|RXZpbE9TW|UAdgBpAGwATwBTAFgA|V2aWxPU1)/ ascii
		$enc_x1 = /(AGUAdABfAGwAYQB1AG4AYwBoAF8AYQBnAGUAbgB0AF8AZABpAHIAZQBjAHQAbwByAHkA|cAZQB0AF8AbABhAHUAbgBjAGgAXwBhAGcAZQBuAHQAXwBkAGkAcgBlAGMAdABvAHIAeQ|dldF9sYXVuY2hfYWdlbnRfZGlyZWN0b3J5|Z2V0X2xhdW5jaF9hZ2VudF9kaXJlY3Rvcn|ZwBlAHQAXwBsAGEAdQBuAGMAaABfAGEAZwBlAG4AdABfAGQAaQByAGUAYwB0AG8AcgB5A|ZXRfbGF1bmNoX2FnZW50X2RpcmVjdG9ye)/ ascii

	condition:
		uint32( 0 ) == 0x752f2123 and $h1 at 0 and filesize < 30KB and all of ( $s* ) and 1 of ( $x* ) or 1 of ( $enc_x* )
}
rule SIGNATURE_BASE_APT_Equation_Group_Op_Triangulation_Triangledb_Implant_Jun23_1 : FILE {
    meta:
		description = "Detects TriangleDB implant found being used in Operation Triangulation on iOS devices (maybe also used on macOS systems)"
		author = "Florian Roth"
		id = "d81a5103-41c8-5dba-a560-8fb5514f6c0a"
		date = "2023-06-21"
		modified = "2023-12-05"
		reference = "https://securelist.com/triangledb-triangulation-implant/110050/"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/apt_eqgrp_triangulation_jun23.yar#L2-L18"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "486b19ddb8b182dbba882359f7eb416735e76f9cda5aea1b290fb5c6b44960c5"
		score = 80
		quality = 85
		tags = "FILE"

	strings:
		$s1 = "unmungeHexString" ascii fullword
		$s2 = "CRPwrInfo" ascii fullword
		$s3 = "CRConfig" ascii fullword
		$s4 = "CRXConfigureDBServer" ascii fullword

	condition:
		( uint16( 0 ) == 0xfacf and filesize < 30MB and $s1 and 2 of them ) or all of them
}
rule SIGNATURE_BASE_EXT_SUSP_OBFUSC_Macos_Roothelper_Obfuscated : FILE {
    meta:
		description = "Yara for the public tool 'roothelper'. Used by XCSSET (https://gist.github.com/NullArray/f39b026b9e0d19f1e17390a244d679ec)"
		author = "im0prtp3"
		id = "7ff91c00-8178-525c-bb41-d09cf7cda588"
		date = "2021-06-07"
		modified = "2023-12-05"
		reference = "https://twitter.com/imp0rtp3/status/1401912205621202944"
		source_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/yara/gen_hktl_roothelper.yar#L2-L55"
		license_url = "https://github.com/Neo23x0/signature-base/blob/e737ebd96c27a52ee99485d4d3e02e9c256d1d3a/LICENSE"
		logic_hash = "2121de0409f3f8e4c4e079944efb605776e0475cadc25607eb888cc6461ecaf3"
		score = 65
		quality = 83
		tags = "FILE"

	strings:
		$a1 = "E: neither argv[0] nor $_ works." fullword
		$b1 = "shll=%s\n" fullword
		$b2 = "argv[%d]=%.60s\n" fullword
		$b3 = "getenv(%s)=%s\n" fullword
		$b4 = "argc=%d\n" fullword
		$b5 = "argv=<null>\n" fullword
		$c1 = "%s%s%s: %s\n" fullword
		$c2 = "x%lx" fullword
		$c3 = "=%lu %d" fullword
		$c4 = "%lu %d%c" fullword
		$f1 = "rmarg"
		$f2 = "chkenv"
		$f3 = "untraceable"
		$f4 = "arc4"
		$f6 = "stte"
		$f7 = "with_file"
		$opcodes_1 = { 99 F7 7D ?? 4C 63 C2 42 0F B6 14 01 0F B6 3D }
		$opcodes_2 = { C6 [3] 00 00 00 C6 [3] 00 00 00 C6 [3] 00 00 00 8A 05 [2] 00 00 0F B6 [3] 00 00 89 CA }
		$opcodes_3 = { E8 [2] FF FF	8B 85 ?? F? FF FF 2B 85 ?? F? FF FF	83 ?? 01 89 85 ?? F? FF FF E9 ?? 00 00 00 }
		$weak_opcodes_1 = {48 8B 45 ?? 48 8B 00 48 3B 45 ??	0F 95 C1 88 4D ??}
		$weak_opcodes_2 = {	48 8B 45 ??	48 83 38 ??	0F 95 C1 88 4D ?? }

	condition:
		( uint32( 0 ) == 0xfeedface or uint32( 0 ) == 0xcefaedfe or uint32( 0 ) == 0xfeedfacf or uint32( 0 ) == 0xcffaedfe or uint32( 0 ) == 0xcafebabe or uint32( 0 ) == 0xbebafeca ) and ( $a1 or 3 of ( $b* ) or 5 of ( $f* ) or all of ( $opcodes* ) or ( 2 of ( $b* ) and ( 2 of ( $c* ) or 2 of ( $opcodes* ) ) ) or ( 3 of ( $c* ) and 4 of ( $f* ) ) or ( 2 of ( $opcodes* ) and ( all of ( $weak_opcodes* ) or 3 of ( $c* ) ) ) )
}
